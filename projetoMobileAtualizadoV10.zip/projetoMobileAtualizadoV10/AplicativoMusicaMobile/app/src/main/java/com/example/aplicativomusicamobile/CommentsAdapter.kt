package com.example.aplicativomusicamobile

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CommentsAdapter(
    private var lista: List<ComentarioPostagem>
) : RecyclerView.Adapter<CommentsAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val txtUsuario: TextView = view.findViewById(R.id.txtUsuarioComentario)
        val txtComentario: TextView = view.findViewById(R.id.txtComentarioResposta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_comentario, parent, false)

        return VH(view)
    }

    override fun getItemCount(): Int = lista.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val comentario = lista[position]

        holder.txtUsuario.text = comentario.usuario
        holder.txtComentario.text = comentario.comentario
    }

    fun atualizar(novaLista: List<ComentarioPostagem>) {
        lista = novaLista
        notifyDataSetChanged()
    }
}