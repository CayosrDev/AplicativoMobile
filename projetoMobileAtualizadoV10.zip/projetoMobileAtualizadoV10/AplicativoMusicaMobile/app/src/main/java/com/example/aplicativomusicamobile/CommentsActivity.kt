package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CommentsActivity : AppCompatActivity() {

    private lateinit var recyclerComentarios: RecyclerView
    private lateinit var edtComentario: EditText
    private lateinit var btnEnviarComentario: Button
    private lateinit var adapter: CommentsAdapter

    private var idPostagem: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comments)

        idPostagem = intent.getIntExtra("id_postagem", 0)

        recyclerComentarios = findViewById(R.id.recyclerComentarios)
        edtComentario = findViewById(R.id.edtComentario)
        btnEnviarComentario = findViewById(R.id.btnEnviarComentario)

        recyclerComentarios.layoutManager = LinearLayoutManager(this)

        adapter = CommentsAdapter(emptyList())
        recyclerComentarios.adapter = adapter

        carregarComentarios()

        btnEnviarComentario.setOnClickListener {
            val texto = edtComentario.text.toString().trim()

            if (texto.isEmpty()) {
                Toast.makeText(this, "Digite uma resposta", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            RetrofitClient.api.criarComentario(
                idPostagem,
                UsuarioSession.idUsuario,
                texto
            ).enqueue(object : Callback<Resposta> {

                override fun onResponse(
                    call: Call<Resposta>,
                    response: Response<Resposta>
                ) {
                    Toast.makeText(
                        this@CommentsActivity,
                        response.body()?.mensagem ?: "Comentário enviado",
                        Toast.LENGTH_SHORT
                    ).show()

                    edtComentario.setText("")
                    carregarComentarios()
                }

                override fun onFailure(
                    call: Call<Resposta>,
                    t: Throwable
                ) {
                    Toast.makeText(
                        this@CommentsActivity,
                        "Erro: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }
    }

    private fun carregarComentarios() {
        RetrofitClient.api.comentariosPostagem(idPostagem)
            .enqueue(object : Callback<List<ComentarioPostagem>> {

                override fun onResponse(
                    call: Call<List<ComentarioPostagem>>,
                    response: Response<List<ComentarioPostagem>>
                ) {
                    adapter.atualizar(response.body() ?: emptyList())
                }

                override fun onFailure(
                    call: Call<List<ComentarioPostagem>>,
                    t: Throwable
                ) {
                    Toast.makeText(
                        this@CommentsActivity,
                        "Erro: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }
}