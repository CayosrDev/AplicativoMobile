package com.example.aplicativomusicamobile

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MapActivity : AppCompatActivity() {

    private lateinit var mapView: MapView
    private lateinit var bottomNav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Configuration.getInstance().userAgentValue = packageName

        setContentView(R.layout.activity_map)

        mapView = findViewById(R.id.mapView)
        bottomNav = findViewById(R.id.bottomNav)

        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)

        val centroInicial = GeoPoint(-16.6869, -49.2648) // Goiânia
        mapView.controller.setZoom(12.0)
        mapView.controller.setCenter(centroInicial)

        configurarMenu()
        carregarPostagensMapa()
    }

    private fun carregarPostagensMapa() {
        RetrofitClient.api.mapaPostagens()
            .enqueue(object : Callback<List<MapaPostagem>> {

                override fun onResponse(
                    call: Call<List<MapaPostagem>>,
                    response: Response<List<MapaPostagem>>
                ) {
                    val lista = response.body() ?: emptyList()

                    mapView.overlays.clear()

                    for (post in lista) {
                        if (post.latitude != null && post.longitude != null) {
                            val ponto = GeoPoint(post.latitude, post.longitude)

                            val marker = Marker(mapView)
                            marker.position = ponto
                            marker.title = "${post.musica} - ${post.artista}"
                            marker.snippet = "${post.usuario}: ${post.comentario ?: ""}"
                            marker.setAnchor(
                                Marker.ANCHOR_CENTER,
                                Marker.ANCHOR_BOTTOM
                            )

                            mapView.overlays.add(marker)
                        }
                    }

                    mapView.invalidate()
                }

                override fun onFailure(
                    call: Call<List<MapaPostagem>>,
                    t: Throwable
                ) {
                }
            })
    }

    private fun configurarMenu() {
        bottomNav.selectedItemId = R.id.nav_map

        bottomNav.setOnItemSelectedListener {

            when (it.itemId) {

                R.id.nav_home -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_search -> {
                    startActivity(Intent(this, SearchActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_feed -> {
                    startActivity(Intent(this, FeedActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_map -> true

                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                else -> false
            }
        }
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }
}