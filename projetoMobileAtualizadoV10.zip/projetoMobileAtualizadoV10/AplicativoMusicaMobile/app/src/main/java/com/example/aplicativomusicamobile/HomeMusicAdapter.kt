package com.example.aplicativomusicamobile

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class HomeMusicAdapter(
    private val lista: List<MusicaDeezer>,
    private val onClick: (MusicaDeezer) -> Unit
) : RecyclerView.Adapter<HomeMusicAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val imgCapa: ImageView = view.findViewById(R.id.imgCapa)
        val txtTitulo: TextView = view.findViewById(R.id.txtTitulo)
        val txtArtista: TextView = view.findViewById(R.id.txtArtista)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_home_musica, parent, false)
        return VH(view)
    }

    override fun getItemCount() = lista.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val musica = lista[position]

        holder.txtTitulo.text = musica.title
        holder.txtArtista.text = musica.artist.name

        Glide.with(holder.itemView.context)
            .load(musica.album.cover_medium)
            .placeholder(R.drawable.logo)
            .into(holder.imgCapa)

        holder.itemView.setOnClickListener {
            onClick(musica)
        }
    }
}