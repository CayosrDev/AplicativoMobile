package com.example.aplicativomusicamobile

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CompatibilityAdapter(
    private var lista: List<CompatibilidadeUsuario>,
    private val onClick: (CompatibilidadeUsuario) -> Unit
) : RecyclerView.Adapter<CompatibilityAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val txtUsuario: TextView = view.findViewById(R.id.txtUsuarioCompat)
        val txtPorcentagem: TextView = view.findViewById(R.id.txtPorcentagem)
        val txtDetalhes: TextView = view.findViewById(R.id.txtDetalhesCompat)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_compatibilidade, parent, false)

        return VH(view)
    }

    override fun getItemCount() = lista.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = lista[position]

        holder.txtUsuario.text = item.usuario
        holder.txtPorcentagem.text = "${item.compatibilidade}% compatível"
        holder.txtDetalhes.text =
            "${item.generos_em_comum} gênero(s) em comum"

        holder.itemView.setOnClickListener {
            onClick(item)
        }
    }

    fun atualizar(novaLista: List<CompatibilidadeUsuario>) {
        lista = novaLista
        notifyDataSetChanged()
    }
}