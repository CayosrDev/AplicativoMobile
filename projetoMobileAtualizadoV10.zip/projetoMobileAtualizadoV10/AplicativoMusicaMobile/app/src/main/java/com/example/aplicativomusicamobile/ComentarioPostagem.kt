package com.example.aplicativomusicamobile

data class ComentarioPostagem(
    val id_comentario: Int,
    val id_postagem: Int,
    val usuario: String,
    val comentario: String,
    val data_comentario: String?
)