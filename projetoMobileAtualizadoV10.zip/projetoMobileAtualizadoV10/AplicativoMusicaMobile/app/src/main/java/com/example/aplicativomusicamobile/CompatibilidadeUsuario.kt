package com.example.aplicativomusicamobile

data class CompatibilidadeUsuario(
    val id_usuario: Int,
    val usuario: String,
    val generos_em_comum: Int,
    val total_generos_usuario: Int,
    val compatibilidade: Int
)