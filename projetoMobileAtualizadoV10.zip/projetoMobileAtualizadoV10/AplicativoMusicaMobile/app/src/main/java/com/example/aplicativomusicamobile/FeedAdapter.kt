package com.example.aplicativomusicamobile

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class FeedAdapter(
    private var itens: List<FeedPost>,
    private val onCurtir: (FeedPost) -> Unit,
    private val onDislike: (FeedPost) -> Unit,
    private val onResponder: (FeedPost) -> Unit,
    private val onEditar: (FeedPost) -> Unit,
    private val onExcluir: (FeedPost) -> Unit
) : RecyclerView.Adapter<FeedAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val imgAlbum: ImageView = view.findViewById(R.id.imgAlbum)
        val txtUsuario: TextView = view.findViewById(R.id.txtNomeUsuario)
        val txtMusica: TextView = view.findViewById(R.id.txtMusica)
        val txtArtista: TextView = view.findViewById(R.id.txtArtista)
        val txtComentario: TextView = view.findViewById(R.id.txtComentario)
        val txtCurtidas: TextView = view.findViewById(R.id.txtCurtidas)
        val btnCurtir: TextView = view.findViewById(R.id.btnCurtir)
        val btnDislike: TextView = view.findViewById(R.id.btnDislike)
        val txtDislikes: TextView = view.findViewById(R.id.txtDislikes)
        val btnResponder: TextView = view.findViewById(R.id.btnResponder)
        val btnEditar: TextView = view.findViewById(R.id.btnEditar)
        val btnExcluir: TextView = view.findViewById(R.id.btnExcluir)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_feed, parent, false)

        return VH(view)
    }

    override fun getItemCount(): Int = itens.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val post = itens[position]

        holder.txtUsuario.text = post.usuario
        holder.txtMusica.text = post.musica
        holder.txtArtista.text = post.artista
        holder.txtComentario.text = post.comentario
        holder.txtCurtidas.text = "${post.curtidas} curtidas"

        Glide.with(holder.itemView.context)
            .load(post.capa_url)
            .placeholder(R.drawable.logo)
            .into(holder.imgAlbum)

        if (post.curtido == 1) {
            holder.btnCurtir.text = "♥"
            holder.btnCurtir.setTextColor(
                holder.itemView.context.getColor(android.R.color.holo_red_light)
            )
        } else {
            holder.btnCurtir.text = "♡"
            holder.btnCurtir.setTextColor(
                holder.itemView.context.getColor(R.color.neon_pink)
            )
        }

        holder.btnCurtir.setOnClickListener {
            onCurtir(post)
        }
        holder.txtDislikes.text = post.dislikes.toString()

        if (post.descurtido == 1) {
            holder.btnDislike.setTextColor(
                holder.itemView.context.getColor(android.R.color.holo_red_light)
            )
        } else {
            holder.btnDislike.setTextColor(
                holder.itemView.context.getColor(R.color.text_secondary)
            )
        }

        holder.btnDislike.setOnClickListener {
            onDislike(post)
        }
        holder.btnResponder.setOnClickListener {
            onResponder(post)
        }
        if (post.id_usuario == UsuarioSession.idUsuario) {
            holder.btnEditar.visibility = View.VISIBLE
            holder.btnExcluir.visibility = View.VISIBLE
        } else {
            holder.btnEditar.visibility = View.GONE
            holder.btnExcluir.visibility = View.GONE
        }
        holder.btnEditar.setOnClickListener {
            onEditar(post)
        }

        holder.btnExcluir.setOnClickListener {
            onExcluir(post)
        }
    }


    fun atualizar(novaLista: List<FeedPost>) {
        itens = novaLista
        notifyDataSetChanged()
    }
}