package com.example.aplicativomusicamobile

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class UsuarioAdapter(
    private var lista: List<Usuario>,
    private val onClick: (Usuario) -> Unit
) : RecyclerView.Adapter<UsuarioAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val txtNome: TextView = view.findViewById(R.id.txtNomeUsuario)
        val txtBio: TextView = view.findViewById(R.id.txtBioUsuario)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_usuario, parent, false)

        return VH(view)
    }

    override fun getItemCount() = lista.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val usuario = lista[position]

        holder.txtNome.text = usuario.nome
        holder.txtBio.text = usuario.bio ?: "Sem bio"

        holder.itemView.setOnClickListener {
            onClick(usuario)
        }
    }

    fun atualizar(novaLista: List<Usuario>) {
        lista = novaLista
        notifyDataSetChanged()
    }
}