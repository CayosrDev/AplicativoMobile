package com.example.aplicativomusicamobile

data class Usuario(
    val id_usuario: Int,
    val nome: String,
    val bio: String?
)