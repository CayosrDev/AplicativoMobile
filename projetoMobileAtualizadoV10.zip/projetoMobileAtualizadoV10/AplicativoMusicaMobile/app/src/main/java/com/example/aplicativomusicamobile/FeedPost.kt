package com.example.aplicativomusicamobile

data class FeedPost(
    val id_postagem: Int,
    val usuario: String,
    val musica: String,
    val artista: String,
    val comentario: String,
    val latitude: String?,
    val longitude: String?,
    val data_postagem: String?,
    val curtido: Int,
    val curtidas: Int,
    val capa_url: String?,
    val dislikes: Int,
    val descurtido: Int,
    val id_usuario: Int,

)
