package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.content.Intent
import android.view.View
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.chip.Chip
import android.view.inputmethod.EditorInfo


class SearchActivity : AppCompatActivity() {

    private lateinit var edtBusca: EditText
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        edtBusca = findViewById(R.id.edtBusca)
        edtBusca.setOnEditorActionListener { _, actionId, _ ->

            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) {

                realizarBusca()
                true

            } else {
                false
            }
        }
        recyclerView = findViewById(R.id.recyclerBusca)

        recyclerView.layoutManager = LinearLayoutManager(this)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        // Esconde menu quando teclado abrir
        window.decorView.viewTreeObserver.addOnGlobalLayoutListener {

            val rect = android.graphics.Rect()
            window.decorView.getWindowVisibleDisplayFrame(rect)

            val screenHeight = window.decorView.height
            val keypadHeight = screenHeight - rect.bottom

            if (keypadHeight > screenHeight * 0.15) {
                bottomNav.visibility = View.GONE
            } else {
                bottomNav.visibility = View.VISIBLE
            }
        }
        edtBusca.setOnEditorActionListener { _, actionId, _ ->

            if (actionId == EditorInfo.IME_ACTION_SEARCH) {

                realizarBusca()
                true

            } else {
                false
            }
        }

        bottomNav.selectedItemId = R.id.nav_search

        bottomNav.setOnItemSelectedListener {

            when (it.itemId) {

                R.id.nav_home -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_search -> true

                R.id.nav_feed -> {
                    startActivity(Intent(this, FeedActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_map -> {
                    startActivity(Intent(this, MapActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                else -> false
            }
        }

        findViewById<Chip>(R.id.chipKendrick).setOnClickListener {
            edtBusca.setText("Kendrick Lamar")
            realizarBusca()
        }

        findViewById<Chip>(R.id.chipWeeknd).setOnClickListener {
            edtBusca.setText("The Weeknd")
            realizarBusca()
        }
        findViewById<Chip>(R.id.chipSabrina)
            .setOnClickListener {
                edtBusca.setText("Sabrina Carpenter")
                realizarBusca()
            }

        findViewById<Chip>(R.id.chipDua)
            .setOnClickListener {
                edtBusca.setText("Dua Lipa")
                realizarBusca()
            }

        findViewById<Chip>(R.id.chipQueen)
            .setOnClickListener {
                edtBusca.setText("Queen")
                realizarBusca()
            }
    }

    private fun realizarBusca() {

        val termo = edtBusca.text.toString().trim()

        if (termo.isEmpty()) {
            Toast.makeText(
                this,
                "Digite uma música ou artista",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        DeezerClient.api.buscarMusicas(termo)
            .enqueue(object : Callback<DeezerResponse> {

                override fun onResponse(
                    call: Call<DeezerResponse>,
                    response: Response<DeezerResponse>
                ) {

                    val musicas =
                        response.body()?.data ?: emptyList()

                    recyclerView.adapter =
                        MusicaAdapter(musicas) { musica ->

                            val intent =
                                Intent(this@SearchActivity, MusicDetailActivity::class.java)

                            intent.putExtra("titulo", musica.title)
                            intent.putExtra("artista", musica.artist.name)
                            intent.putExtra("capa", musica.album.cover_medium)
                            intent.putExtra("preview", musica.preview)

                            startActivity(intent)
                        }
                }

                override fun onFailure(
                    call: Call<DeezerResponse>,
                    t: Throwable
                ) {

                    Toast.makeText(
                        this@SearchActivity,
                        t.message,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }
}