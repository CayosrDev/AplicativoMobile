package com.example.aplicativomusicamobile

data class Resposta(
    val status: String,
    val mensagem: String,
    val seguindo: Int? = null
)