package com.example.aplicativomusicamobile

data class MapaPostagem(
    val id_postagem: Int,
    val usuario: String,
    val musica: String,
    val artista: String,
    val comentario: String?,
    val latitude: Double?,
    val longitude: Double?
)