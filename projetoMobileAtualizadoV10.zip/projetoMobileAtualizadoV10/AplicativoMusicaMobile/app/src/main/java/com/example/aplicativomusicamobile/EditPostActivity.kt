package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class EditPostActivity : AppCompatActivity() {

    private lateinit var edtComentario: EditText
    private lateinit var btnSalvar: Button

    private var idPostagem = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_post)

        edtComentario =
            findViewById(R.id.edtComentario)

        btnSalvar =
            findViewById(R.id.btnSalvar)

        idPostagem =
            intent.getIntExtra("id_postagem", 0)

        edtComentario.setText(
            intent.getStringExtra("comentario")
        )

        btnSalvar.setOnClickListener {

            RetrofitClient.api.editarPostagem(
                idPostagem,
                edtComentario.text.toString()
            ).enqueue(object : Callback<Resposta> {

                override fun onResponse(
                    call: Call<Resposta>,
                    response: Response<Resposta>
                ) {

                    Toast.makeText(
                        this@EditPostActivity,
                        "Postagem atualizada",
                        Toast.LENGTH_SHORT
                    ).show()

                    finish()
                }

                override fun onFailure(
                    call: Call<Resposta>,
                    t: Throwable
                ) {

                    Toast.makeText(
                        this@EditPostActivity,
                        t.message,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }
    }
}