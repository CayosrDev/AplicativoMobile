package com.example.aplicativomusicamobile

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UsersActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var adapter: UsuarioAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_users)

        recycler = findViewById(R.id.recyclerUsuarios)
        recycler.layoutManager = LinearLayoutManager(this)

        adapter = UsuarioAdapter(emptyList()) { usuario ->
            val intent = Intent(this, PublicProfileActivity::class.java)
            intent.putExtra("id_usuario", usuario.id_usuario)
            intent.putExtra("compatibilidade", 0)
            startActivity(intent)
        }

        recycler.adapter = adapter

        carregarUsuarios()
    }

    private fun carregarUsuarios() {
        RetrofitClient.api.listarUsuarios()
            .enqueue(object : Callback<List<Usuario>> {

                override fun onResponse(
                    call: Call<List<Usuario>>,
                    response: Response<List<Usuario>>
                ) {
                    adapter.atualizar(response.body() ?: emptyList())
                }

                override fun onFailure(
                    call: Call<List<Usuario>>,
                    t: Throwable
                ) {
                    Toast.makeText(
                        this@UsersActivity,
                        "Erro: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }
}