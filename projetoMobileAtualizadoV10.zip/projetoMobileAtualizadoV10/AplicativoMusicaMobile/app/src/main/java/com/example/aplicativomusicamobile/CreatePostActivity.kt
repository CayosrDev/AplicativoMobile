package com.example.aplicativomusicamobile

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.widget.addTextChangedListener
import com.google.android.gms.location.LocationServices
import com.google.android.material.bottomnavigation.BottomNavigationView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.annotation.SuppressLint

class CreatePostActivity : AppCompatActivity() {

    private lateinit var edtMusica: EditText
    private lateinit var edtComentario: EditText
    private lateinit var btnPostar: Button

    private var artistaRecebido: String? = null
    private var previewRecebido: String? = null
    private var capaRecebida: String? = null

    private var latitudeAtual: Double? = null
    private var longitudeAtual: Double? = null

    companion object {
        private const val REQUEST_LOCATION = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_post)

        edtMusica = findViewById(R.id.edtMusica)
        edtComentario = findViewById(R.id.edtComentario)
        btnPostar = findViewById(R.id.btnPostar)

        val txtContador = findViewById<TextView>(R.id.txtContador)

        val tituloRecebido = intent.getStringExtra("titulo")
        artistaRecebido = intent.getStringExtra("artista")
        capaRecebida = intent.getStringExtra("capa")
        previewRecebido = intent.getStringExtra("preview")

        if (!tituloRecebido.isNullOrEmpty()) {
            edtMusica.setText(tituloRecebido)
        }

        edtComentario.addTextChangedListener {
            txtContador.text = "${edtComentario.text.length}/200"
        }

        obterLocalizacaoAtual()

        btnPostar.setOnClickListener {
            val nomeMusica = edtMusica.text.toString().trim()
            val comentario = edtComentario.text.toString().trim()

            if (nomeMusica.isEmpty()) {
                Toast.makeText(this, "Informe a música", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (comentario.isEmpty()) {
                Toast.makeText(this, "Escreva um comentário", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!artistaRecebido.isNullOrEmpty()) {
                salvarMusicaDeezerEPostar(nomeMusica, comentario)
            } else {
                buscarIdMusicaEPostar(nomeMusica, comentario)
            }
        }

        configurarMenuInferior()
    }

    @SuppressLint("MissingPermission")
    private fun obterLocalizacaoAtual() {
        val fusedLocationClient =
            LocationServices.getFusedLocationProviderClient(this)

        if (
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                REQUEST_LOCATION
            )
            return
        }

        fusedLocationClient.lastLocation
            .addOnSuccessListener { location ->
                if (location != null) {
                    latitudeAtual = location.latitude
                    longitudeAtual = location.longitude
                }
            }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (
            requestCode == REQUEST_LOCATION &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            obterLocalizacaoAtual()
        }
    }

    private fun salvarMusicaDeezerEPostar(
        nomeMusica: String,
        comentario: String
    ) {
        RetrofitClient.api.salvarMusicaDeezer(
            nomeMusica,
            artistaRecebido ?: "",
            null,
            previewRecebido,
            null,
            capaRecebida
        ).enqueue(object : Callback<SalvarMusicaResponse> {

            override fun onResponse(
                call: Call<SalvarMusicaResponse>,
                response: Response<SalvarMusicaResponse>
            ) {
                val resposta = response.body()

                if (resposta?.status == "ok" && resposta.id_musica != null) {
                    criarPostagemComIdMusica(
                        resposta.id_musica,
                        comentario
                    )
                } else {
                    Toast.makeText(
                        this@CreatePostActivity,
                        resposta?.mensagem ?: "Erro ao salvar música",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            override fun onFailure(
                call: Call<SalvarMusicaResponse>,
                t: Throwable
            ) {
                Toast.makeText(
                    this@CreatePostActivity,
                    "Erro: ${t.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    private fun buscarIdMusicaEPostar(
        nomeMusica: String,
        comentario: String
    ) {
        RetrofitClient.api.buscarIdMusica(nomeMusica)
            .enqueue(object : Callback<MusicaId> {

                override fun onResponse(
                    call: Call<MusicaId>,
                    response: Response<MusicaId>
                ) {
                    val musica = response.body()

                    if (musica?.id_musica != null) {
                        criarPostagemComIdMusica(
                            musica.id_musica,
                            comentario
                        )
                    } else {
                        Toast.makeText(
                            this@CreatePostActivity,
                            "Música não encontrada",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(
                    call: Call<MusicaId>,
                    t: Throwable
                ) {
                    Toast.makeText(
                        this@CreatePostActivity,
                        "Erro: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }

    private fun criarPostagemComIdMusica(
        idMusica: Int,
        comentario: String
    ) {
        RetrofitClient.api.criarPostagem(
            UsuarioSession.idUsuario,
            idMusica,
            comentario,
            latitudeAtual,
            longitudeAtual
        ).enqueue(object : Callback<Resposta> {

            override fun onResponse(
                call: Call<Resposta>,
                response: Response<Resposta>
            ) {
                val resposta = response.body()

                Toast.makeText(
                    this@CreatePostActivity,
                    resposta?.mensagem ?: "Postagem criada",
                    Toast.LENGTH_SHORT
                ).show()

                if (resposta?.status == "ok") {
                    edtComentario.setText("")
                    finish()
                }
            }

            override fun onFailure(
                call: Call<Resposta>,
                t: Throwable
            ) {
                Toast.makeText(
                    this@CreatePostActivity,
                    "Erro: ${t.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    private fun configurarMenuInferior() {
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        bottomNav.selectedItemId = R.id.nav_feed

        bottomNav.setOnItemSelectedListener {

            when (it.itemId) {

                R.id.nav_home -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_search -> {
                    startActivity(Intent(this, SearchActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_feed -> {
                    startActivity(Intent(this, FeedActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_map -> {
                    startActivity(Intent(this, MapActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                else -> false
            }
        }

        window.decorView.viewTreeObserver.addOnGlobalLayoutListener {
            val rect = android.graphics.Rect()
            window.decorView.getWindowVisibleDisplayFrame(rect)

            val screenHeight = window.decorView.height
            val keypadHeight = screenHeight - rect.bottom

            bottomNav.visibility =
                if (keypadHeight > screenHeight * 0.15) {
                    View.GONE
                } else {
                    View.VISIBLE
                }
        }
    }
}