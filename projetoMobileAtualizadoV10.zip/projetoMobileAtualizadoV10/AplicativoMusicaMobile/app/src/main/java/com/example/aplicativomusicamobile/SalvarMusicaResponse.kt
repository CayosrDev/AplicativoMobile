package com.example.aplicativomusicamobile

data class SalvarMusicaResponse(
    val status: String,
    val id_musica: Int?,
    val mensagem: String?
)