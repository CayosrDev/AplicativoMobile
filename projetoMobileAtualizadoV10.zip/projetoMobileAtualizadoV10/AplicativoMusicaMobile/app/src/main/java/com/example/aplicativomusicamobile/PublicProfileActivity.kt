package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PublicProfileActivity : AppCompatActivity() {

    private lateinit var txtNome: TextView
    private lateinit var txtEmail: TextView
    private lateinit var txtBio: TextView
    private lateinit var txtCompatibilidade: TextView
    private lateinit var txtStats: TextView

    private lateinit var btnSeguir: Button
    private lateinit var btnVerCompatibilidade: Button

    private var idUsuarioVisitado = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_public_profile)

        txtNome = findViewById(R.id.txtNomePublico)
        txtEmail = findViewById(R.id.txtEmailPublico)
        txtBio = findViewById(R.id.txtBioPublica)
        txtCompatibilidade = findViewById(R.id.txtCompatibilidadePublica)
        txtStats = findViewById(R.id.txtStatsPublico)

        btnSeguir = findViewById(R.id.btnSeguir)

        btnVerCompatibilidade =
            findViewById(R.id.btnVerCompatibilidadePublica)

        idUsuarioVisitado =
            intent.getIntExtra("id_usuario", 0)

        carregarPerfilPublico()

        btnVerCompatibilidade.setOnClickListener {
            carregarCompatibilidade()
        }

        btnSeguir.setOnClickListener {

            RetrofitClient.api.seguirUsuario(
                UsuarioSession.idUsuario,
                idUsuarioVisitado
            ).enqueue(object : Callback<Resposta> {

                override fun onResponse(
                    call: Call<Resposta>,
                    response: Response<Resposta>
                ) {
                    val resposta = response.body()

                    Toast.makeText(
                        this@PublicProfileActivity,
                        resposta?.mensagem ?: "Ação realizada",
                        Toast.LENGTH_SHORT
                    ).show()

                    if (resposta?.seguindo == 1) {
                        btnSeguir.text = "Seguindo"
                    } else if (resposta?.seguindo == 0) {
                        btnSeguir.text = "Seguir"
                    }
                }

                override fun onFailure(
                    call: Call<Resposta>,
                    t: Throwable
                ) {
                    Toast.makeText(
                        this@PublicProfileActivity,
                        "Erro: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }
    }

    private fun carregarPerfilPublico() {

        RetrofitClient.api.perfilUsuario(idUsuarioVisitado)
            .enqueue(object : Callback<PerfilUsuario> {

                override fun onResponse(
                    call: Call<PerfilUsuario>,
                    response: Response<PerfilUsuario>
                ) {

                    val perfil = response.body()

                    if (perfil != null) {

                        txtNome.text = perfil.nome
                        txtEmail.text = perfil.email
                        txtBio.text = perfil.bio ?: "Sem bio"

                        txtStats.text =
                            "Posts: ${perfil.total_postagens} | Curtidas: ${perfil.curtidas_recebidas}"
                    }
                }

                override fun onFailure(
                    call: Call<PerfilUsuario>,
                    t: Throwable
                ) {

                    Toast.makeText(
                        this@PublicProfileActivity,
                        "Erro: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }

    private fun carregarCompatibilidade() {

        RetrofitClient.api.compatibilidade(
            UsuarioSession.idUsuario
        ).enqueue(
            object : Callback<List<CompatibilidadeUsuario>> {

                override fun onResponse(
                    call: Call<List<CompatibilidadeUsuario>>,
                    response: Response<List<CompatibilidadeUsuario>>
                ) {

                    val lista =
                        response.body() ?: emptyList()

                    val usuarioCompat =
                        lista.find {
                            it.id_usuario == idUsuarioVisitado
                        }

                    if (usuarioCompat != null) {

                        txtCompatibilidade.text =
                            "${usuarioCompat.compatibilidade}% compatível\n${usuarioCompat.generos_em_comum} gênero(s) em comum"

                    } else {

                        txtCompatibilidade.text =
                            "Sem compatibilidade calculada"
                    }
                }

                override fun onFailure(
                    call: Call<List<CompatibilidadeUsuario>>,
                    t: Throwable
                ) {

                    txtCompatibilidade.text =
                        "Compatibilidade indisponível"
                }
            })
    }
}