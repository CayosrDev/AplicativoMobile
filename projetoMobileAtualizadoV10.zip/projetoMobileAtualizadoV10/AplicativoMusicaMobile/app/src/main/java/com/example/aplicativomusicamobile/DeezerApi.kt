package com.example.aplicativomusicamobile

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface DeezerApi {

    @GET("search")
    fun buscarMusicas(
        @Query("q") query: String
    ): Call<DeezerResponse>

    @GET("playlist/1111141961/tracks")
    fun topBrasil(): Call<DeezerResponse>

    @GET("playlist/3155776842/tracks")
    fun topMundo(): Call<DeezerResponse>
}