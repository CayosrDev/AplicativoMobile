package com.example.aplicativomusicamobile

import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class MusicDetailActivity : AppCompatActivity() {

    private var mediaPlayer: MediaPlayer? = null
    private var tocandoPreview = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music_detail)

        val img = findViewById<ImageView>(R.id.imgCapa)
        val txtTitulo = findViewById<TextView>(R.id.txtTitulo)
        val txtArtista = findViewById<TextView>(R.id.txtArtista)
        val btnPreview = findViewById<Button>(R.id.btnPreview)
        val btnCriarPost = findViewById<Button>(R.id.btnCriarPost)
        val btnVoltar = findViewById<Button>(R.id.btnVoltar)

        val titulo = intent.getStringExtra("titulo") ?: ""
        val artista = intent.getStringExtra("artista") ?: ""
        val capa = intent.getStringExtra("capa") ?: ""
        val preview = intent.getStringExtra("preview") ?: ""

        txtTitulo.text = titulo
        txtArtista.text = artista

        Glide.with(this)
            .load(capa)
            .into(img)

        btnPreview.setOnClickListener {
            if (preview.isEmpty()) {
                Toast.makeText(this, "Preview indisponível", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!tocandoPreview) {
                mediaPlayer = MediaPlayer().apply {
                    setDataSource(preview)
                    prepareAsync()

                    setOnPreparedListener {
                        start()
                        this@MusicDetailActivity.tocandoPreview = true
                        btnPreview.text = "⏸ Pausar Preview"
                    }

                    setOnCompletionListener {
                        this@MusicDetailActivity.tocandoPreview = false
                        btnPreview.text = "▶ Ouvir Preview"
                    }
                }
            } else {
                mediaPlayer?.stop()
                mediaPlayer?.release()
                mediaPlayer = null
                tocandoPreview = false
                btnPreview.text = "▶ Ouvir Preview"
            }
        }

        btnCriarPost.setOnClickListener {
            val intent = Intent(this, CreatePostActivity::class.java)

            intent.putExtra("titulo", titulo)
            intent.putExtra("artista", artista)
            intent.putExtra("capa", capa)
            intent.putExtra("preview", preview)

            startActivity(intent)
        }

        btnVoltar.setOnClickListener {
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()

        mediaPlayer?.release()
        mediaPlayer = null
    }
}