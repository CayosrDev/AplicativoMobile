package com.example.aplicativomusicamobile

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CompatibilityActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var adapter: CompatibilityAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_compatibility)

        recycler = findViewById(R.id.recyclerCompatibilidade)
        recycler.layoutManager = LinearLayoutManager(this)

        adapter = CompatibilityAdapter(emptyList()) { usuario ->

            val intent = Intent(
                this,
                PublicProfileActivity::class.java
            )

            intent.putExtra(
                "id_usuario",
                usuario.id_usuario
            )

            intent.putExtra(
                "compatibilidade",
                usuario.compatibilidade
            )

            startActivity(intent)
        }

        recycler.adapter = adapter

        carregarCompatibilidade()
    }

    private fun carregarCompatibilidade() {
        RetrofitClient.api.compatibilidade(UsuarioSession.idUsuario)
            .enqueue(object : Callback<List<CompatibilidadeUsuario>> {

                override fun onResponse(
                    call: Call<List<CompatibilidadeUsuario>>,
                    response: Response<List<CompatibilidadeUsuario>>
                ) {
                    adapter.atualizar(response.body() ?: emptyList())
                }

                override fun onFailure(
                    call: Call<List<CompatibilidadeUsuario>>,
                    t: Throwable
                ) {
                    Toast.makeText(
                        this@CompatibilityActivity,
                        "Erro: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }
}