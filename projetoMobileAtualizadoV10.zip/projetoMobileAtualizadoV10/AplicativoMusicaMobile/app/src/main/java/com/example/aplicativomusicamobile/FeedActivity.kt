package com.example.aplicativomusicamobile

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.widget.Button

class FeedActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: FeedAdapter

    private val usuarioAtualId
        get() = UsuarioSession.idUsuario

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_feed)

        recyclerView = findViewById(R.id.recyclerFeed)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val btnNovaPostagem =
            findViewById<Button>(R.id.btnNovaPostagem)

        btnNovaPostagem.setOnClickListener {
            startActivity(Intent(this, CreatePostActivity::class.java))
        }
        val btnVerUsuarios =
            findViewById<Button>(R.id.btnVerUsuarios)

        btnVerUsuarios.setOnClickListener {
            startActivity(Intent(this, UsersActivity::class.java))
        }

        adapter = FeedAdapter(
            emptyList(),

            { post ->
                RetrofitClient.api.curtir(usuarioAtualId, post.id_postagem)
                    .enqueue(object : Callback<Resposta> {
                        override fun onResponse(call: Call<Resposta>, response: Response<Resposta>) {
                            carregarFeed()
                        }

                        override fun onFailure(call: Call<Resposta>, t: Throwable) {}
                    })
            },

            { post ->
                RetrofitClient.api.descurtir(usuarioAtualId, post.id_postagem)
                    .enqueue(object : Callback<Resposta> {
                        override fun onResponse(call: Call<Resposta>, response: Response<Resposta>) {
                            carregarFeed()
                        }

                        override fun onFailure(call: Call<Resposta>, t: Throwable) {}
                    })
            },

            { post ->
                val intent = Intent(this, CommentsActivity::class.java)
                intent.putExtra("id_postagem", post.id_postagem)
                startActivity(intent)
            },

            { post ->
                val intent = Intent(this, EditPostActivity::class.java)
                intent.putExtra("id_postagem", post.id_postagem)
                intent.putExtra("comentario", post.comentario)
                startActivity(intent)
            },

            { post ->
                RetrofitClient.api.excluirPostagem(post.id_postagem)
                    .enqueue(object : Callback<Resposta> {
                        override fun onResponse(call: Call<Resposta>, response: Response<Resposta>) {
                            Toast.makeText(
                                this@FeedActivity,
                                response.body()?.mensagem ?: "Postagem excluída",
                                Toast.LENGTH_SHORT
                            ).show()

                            carregarFeed()
                        }

                        override fun onFailure(call: Call<Resposta>, t: Throwable) {
                            Toast.makeText(
                                this@FeedActivity,
                                "Erro: ${t.message}",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    })
            }
        )
        recyclerView.adapter = adapter

        configurarMenu()
        carregarFeed()
    }
        override fun onResume() {
        super.onResume()
        carregarFeed()
    }
    private fun carregarFeed() {
        RetrofitClient.api.feed(usuarioAtualId)
            .enqueue(object : Callback<List<FeedPost>> {

                override fun onResponse(
                    call: Call<List<FeedPost>>,
                    response: Response<List<FeedPost>>
                ) {
                    adapter.atualizar(response.body() ?: emptyList())
                }

                override fun onFailure(
                    call: Call<List<FeedPost>>,
                    t: Throwable
                ) {
                    Toast.makeText(
                        this@FeedActivity,
                        "Erro: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }

    private fun configurarMenu() {
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        bottomNav.selectedItemId = R.id.nav_feed

        bottomNav.setOnItemSelectedListener {

            when (it.itemId) {

                R.id.nav_home -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_feed -> true

                R.id.nav_search -> {
                    startActivity(Intent(this, SearchActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_map -> {
                    startActivity(Intent(this, MapActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                else -> false
            }
        }

    }
}