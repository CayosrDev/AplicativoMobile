<?php

include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

$sql = "
SELECT
    id_usuario,
    nome,
    bio
FROM usuario
ORDER BY nome
";

$result = $conn->query($sql);

$dados = [];

while($row = $result->fetch_assoc()){
    $dados[] = $row;
}

echo json_encode(
    $dados,
    JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
);