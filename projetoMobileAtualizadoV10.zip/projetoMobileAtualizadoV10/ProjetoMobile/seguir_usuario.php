<?php
include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

$id_usuario = intval($_GET['id_usuario']);
$id_seguindo = intval($_GET['id_seguindo']);

if ($id_usuario == $id_seguindo) {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "Você não pode seguir a si mesmo"
    ]);
    exit;
}

$sqlBusca = "
SELECT id_seguidor
FROM seguidores
WHERE id_usuario = ?
AND id_seguindo = ?
";

$stmt = $conn->prepare($sqlBusca);
$stmt->bind_param("ii", $id_usuario, $id_seguindo);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $sqlDelete = "
    DELETE FROM seguidores
    WHERE id_usuario = ?
    AND id_seguindo = ?
    ";

    $stmtDelete = $conn->prepare($sqlDelete);
    $stmtDelete->bind_param("ii", $id_usuario, $id_seguindo);
    $stmtDelete->execute();

    echo json_encode([
        "status" => "ok",
        "mensagem" => "Você deixou de seguir este usuário",
        "seguindo" => 0
    ]);
    exit;
}

$sqlInsert = "
INSERT INTO seguidores(id_usuario, id_seguindo)
VALUES (?, ?)
";

$stmtInsert = $conn->prepare($sqlInsert);
$stmtInsert->bind_param("ii", $id_usuario, $id_seguindo);

if ($stmtInsert->execute()) {
    echo json_encode([
        "status" => "ok",
        "mensagem" => "Usuário seguido",
        "seguindo" => 1
    ]);
} else {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "Erro ao seguir usuário"
    ]);
}
?>