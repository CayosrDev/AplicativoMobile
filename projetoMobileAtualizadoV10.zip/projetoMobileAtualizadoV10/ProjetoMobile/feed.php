<?php
include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

$id_usuario_logado = isset($_GET['id_usuario'])
    ? intval($_GET['id_usuario'])
    : 0;

$sql = "
SELECT 
    p.id_postagem,
    u.nome AS usuario,
    m.nome AS musica,
    p.id_usuario,
    m.artista,
    m.album,
    m.url_preview,
    p.comentario,
    p.latitude,
    p.longitude,
    m.capa_url,
    p.data_postagem,
    COUNT(c.id_curtida) AS curtidas,
    COUNT(DISTINCT d.id_descurtida) AS dislikes,
    CASE 
        WHEN EXISTS (
            SELECT 1
            FROM curtida c2
            WHERE c2.id_postagem = p.id_postagem
            AND c2.id_usuario = $id_usuario_logado
        )
        THEN 1
        ELSE 0
    END AS curtido,
    CASE 
    WHEN EXISTS (
        SELECT 1 FROM descurtida d2
        WHERE d2.id_postagem = p.id_postagem
        AND d2.id_usuario = $id_usuario_logado
    )
    THEN 1 ELSE 0
END AS descurtido
FROM postagem p
JOIN usuario u 
    ON p.id_usuario = u.id_usuario
JOIN musica m 
    ON p.id_musica = m.id_musica
LEFT JOIN curtida c 
    ON c.id_postagem = p.id_postagem
LEFT JOIN descurtida d
    ON d.id_postagem = p.id_postagem
GROUP BY 
    p.id_postagem,
    u.nome,
    m.nome,
    m.artista,
    m.album,
    m.url_preview,
    m.capa_url,
    p.comentario,
    p.id_usuario,
    p.latitude,
    p.longitude,
    p.data_postagem
ORDER BY 
    p.data_postagem DESC
";

$result = $conn->query($sql);

if (!$result) {
    echo json_encode([
        "status" => "erro",
        "mensagem" => $conn->error
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$dados = [];

while ($row = $result->fetch_assoc()) {
    $row['curtidas'] = intval($row['curtidas']);
    $row['curtido'] = intval($row['curtido']);
    $dados[] = $row;
}

echo json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>