<?php
include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

if (
    !isset($_GET['id_usuario']) ||
    !isset($_GET['id_musica']) ||
    !isset($_GET['comentario'])
) {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "Dados obrigatórios"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$id_usuario = intval($_GET['id_usuario']);
$id_musica = intval($_GET['id_musica']);
$comentario = $_GET['comentario'];

$latitude = isset($_GET['latitude']) && $_GET['latitude'] !== ""
    ? floatval($_GET['latitude'])
    : null;

$longitude = isset($_GET['longitude']) && $_GET['longitude'] !== ""
    ? floatval($_GET['longitude'])
    : null;

$sql = "
INSERT INTO postagem(
    id_usuario,
    id_musica,
    comentario,
    latitude,
    longitude
)
VALUES (?, ?, ?, ?, ?)
";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "iisdd",
    $id_usuario,
    $id_musica,
    $comentario,
    $latitude,
    $longitude
);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "ok",
        "mensagem" => "Postagem criada"
    ], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode([
        "status" => "erro",
        "mensagem" => $stmt->error
    ], JSON_UNESCAPED_UNICODE);
}
?>