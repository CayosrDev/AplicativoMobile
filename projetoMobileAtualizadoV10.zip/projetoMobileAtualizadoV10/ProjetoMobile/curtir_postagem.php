<?php
include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

if (
    !isset($_GET['id_usuario']) ||
    !isset($_GET['id_postagem'])
) {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "Dados obrigatórios"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$id_usuario = intval($_GET['id_usuario']);
$id_postagem = intval($_GET['id_postagem']);

$sqlBusca = "
SELECT id_curtida
FROM curtida
WHERE id_usuario = ?
AND id_postagem = ?
LIMIT 1
";

$stmtBusca = $conn->prepare($sqlBusca);
$stmtBusca->bind_param("ii", $id_usuario, $id_postagem);
$stmtBusca->execute();

$result = $stmtBusca->get_result();

if ($result->num_rows > 0) {
    $curtida = $result->fetch_assoc();
    $id_curtida = intval($curtida['id_curtida']);

    $sqlDelete = "
    DELETE FROM curtida
    WHERE id_curtida = ?
    ";

    $stmtDelete = $conn->prepare($sqlDelete);
    $stmtDelete->bind_param("i", $id_curtida);

    if ($stmtDelete->execute()) {
        echo json_encode([
            "status" => "ok",
            "acao" => "removeu",
            "mensagem" => "Curtida removida"
        ], JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode([
            "status" => "erro",
            "mensagem" => "Erro ao remover curtida"
        ], JSON_UNESCAPED_UNICODE);
    }

    exit;
}

$sqlInsert = "
INSERT INTO curtida (id_usuario, id_postagem)
VALUES (?, ?)
";

$stmtInsert = $conn->prepare($sqlInsert);
$stmtInsert->bind_param("ii", $id_usuario, $id_postagem);

if ($stmtInsert->execute()) {
    echo json_encode([
        "status" => "ok",
        "acao" => "curtiu",
        "mensagem" => "Postagem curtida"
    ], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "Erro ao curtir postagem"
    ], JSON_UNESCAPED_UNICODE);
}
?>