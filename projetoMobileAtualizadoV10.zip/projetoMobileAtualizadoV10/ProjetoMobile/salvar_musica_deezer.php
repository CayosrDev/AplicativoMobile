<?php
include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

if (
    !isset($_GET['nome']) ||
    !isset($_GET['artista'])
) {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "Nome e artista obrigatórios"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$nome = $_GET['nome'];
$artista = $_GET['artista'];
$album = $_GET['album'] ?? null;
$url_preview = $_GET['url_preview'] ?? null;
$api_id = $_GET['api_id'] ?? null;
$capa_url = $_GET['capa_url'] ?? null;

$sqlBusca = "
SELECT id_musica
FROM musica
WHERE nome = ?
AND artista = ?
LIMIT 1
";

$stmtBusca = $conn->prepare($sqlBusca);
$stmtBusca->bind_param("ss", $nome, $artista);
$stmtBusca->execute();

$result = $stmtBusca->get_result();

if ($result->num_rows > 0) {
    $musica = $result->fetch_assoc();

    if (!empty($capa_url)) {
        $sqlUpdate = "
        UPDATE musica
        SET capa_url = ?
        WHERE id_musica = ?
        AND (capa_url IS NULL OR capa_url = '')
        ";

        $stmtUpdate = $conn->prepare($sqlUpdate);
        $stmtUpdate->bind_param("si", $capa_url, $musica['id_musica']);
        $stmtUpdate->execute();
    }

    echo json_encode([
        "status" => "ok",
        "id_musica" => intval($musica['id_musica']),
        "mensagem" => "Música já existente"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$sqlInsert = "
INSERT INTO musica (
    nome,
    artista,
    album,
    url_preview,
    api_id,
    capa_url
)
VALUES (?, ?, ?, ?, ?, ?)
";

$stmtInsert = $conn->prepare($sqlInsert);
$stmtInsert->bind_param(
    "ssssss",
    $nome,
    $artista,
    $album,
    $url_preview,
    $api_id,
    $capa_url
);

if ($stmtInsert->execute()) {
    echo json_encode([
        "status" => "ok",
        "id_musica" => $conn->insert_id,
        "mensagem" => "Música salva"
    ], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode([
        "status" => "erro",
        "mensagem" => $stmtInsert->error
    ], JSON_UNESCAPED_UNICODE);
}
?>