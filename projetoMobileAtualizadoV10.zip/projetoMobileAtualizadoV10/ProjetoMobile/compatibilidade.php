<?php
include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_GET['id_usuario'])) {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "ID do usuário obrigatório"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$id_usuario = intval($_GET['id_usuario']);

$sql = "
SELECT
    u.id_usuario,
    u.nome AS usuario,
    COUNT(DISTINCT m2.id_genero) AS generos_em_comum,
    (
        SELECT COUNT(DISTINCT m_user.id_genero)
        FROM curtida c_user
        JOIN postagem p_user ON c_user.id_postagem = p_user.id_postagem
        JOIN musica m_user ON p_user.id_musica = m_user.id_musica
        WHERE c_user.id_usuario = ?
        AND m_user.id_genero IS NOT NULL
    ) AS total_generos_usuario,
    ROUND(
        (
            COUNT(DISTINCT m2.id_genero) /
            NULLIF((
                SELECT COUNT(DISTINCT m_user2.id_genero)
                FROM curtida c_user2
                JOIN postagem p_user2 ON c_user2.id_postagem = p_user2.id_postagem
                JOIN musica m_user2 ON p_user2.id_musica = m_user2.id_musica
                WHERE c_user2.id_usuario = ?
                AND m_user2.id_genero IS NOT NULL
            ), 0)
        ) * 100
    ) AS compatibilidade
FROM usuario u
JOIN curtida c2 ON u.id_usuario = c2.id_usuario
JOIN postagem p2 ON c2.id_postagem = p2.id_postagem
JOIN musica m2 ON p2.id_musica = m2.id_musica
WHERE u.id_usuario <> ?
AND m2.id_genero IN (
    SELECT DISTINCT m3.id_genero
    FROM curtida c3
    JOIN postagem p3 ON c3.id_postagem = p3.id_postagem
    JOIN musica m3 ON p3.id_musica = m3.id_musica
    WHERE c3.id_usuario = ?
    AND m3.id_genero IS NOT NULL
)
GROUP BY u.id_usuario, u.nome
ORDER BY compatibilidade DESC, generos_em_comum DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "iiii",
    $id_usuario,
    $id_usuario,
    $id_usuario,
    $id_usuario
);
$stmt->execute();

$result = $stmt->get_result();

$dados = [];

while ($row = $result->fetch_assoc()) {
    $row['id_usuario'] = intval($row['id_usuario']);
    $row['generos_em_comum'] = intval($row['generos_em_comum']);
    $row['total_generos_usuario'] = intval($row['total_generos_usuario']);
    $row['compatibilidade'] = intval($row['compatibilidade']);

    $dados[] = $row;
}

echo json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>