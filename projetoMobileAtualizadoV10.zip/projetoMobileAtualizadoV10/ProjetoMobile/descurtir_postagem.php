<?php
include 'conexao.php';
header('Content-Type: application/json; charset=utf-8');

$id_usuario = intval($_GET['id_usuario']);
$id_postagem = intval($_GET['id_postagem']);

$busca = $conn->prepare("
SELECT id_descurtida FROM descurtida
WHERE id_usuario = ? AND id_postagem = ?
");
$busca->bind_param("ii", $id_usuario, $id_postagem);
$busca->execute();
$result = $busca->get_result();

if ($result->num_rows > 0) {
    $delete = $conn->prepare("
    DELETE FROM descurtida
    WHERE id_usuario = ? AND id_postagem = ?
    ");
    $delete->bind_param("ii", $id_usuario, $id_postagem);
    $delete->execute();

    echo json_encode([
        "status" => "ok",
        "mensagem" => "Dislike removido"
    ]);
    exit;
}

$conn->query("
DELETE FROM curtida
WHERE id_usuario = $id_usuario
AND id_postagem = $id_postagem
");

$insert = $conn->prepare("
INSERT INTO descurtida(id_usuario, id_postagem)
VALUES (?, ?)
");
$insert->bind_param("ii", $id_usuario, $id_postagem);

if ($insert->execute()) {
    echo json_encode([
        "status" => "ok",
        "mensagem" => "Postagem recebeu dislike"
    ]);
} else {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "Erro ao dar dislike"
    ]);
}
?>