<?php
include 'conexao.php';
header('Content-Type: application/json; charset=utf-8');

$id_postagem = intval($_GET['id_postagem']);
$id_usuario = intval($_GET['id_usuario']);
$comentario = $_GET['comentario'];

$sql = "
INSERT INTO comentario_postagem(id_postagem, id_usuario, comentario)
VALUES (?, ?, ?)
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iis", $id_postagem, $id_usuario, $comentario);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "ok",
        "mensagem" => "Comentário enviado"
    ], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "Erro ao comentar"
    ], JSON_UNESCAPED_UNICODE);
}
?>