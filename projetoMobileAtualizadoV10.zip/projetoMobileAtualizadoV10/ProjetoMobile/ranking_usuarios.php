<?php
include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

$sql = "
SELECT
    u.id_usuario,
    u.nome AS usuario,
    COUNT(DISTINCT p.id_postagem) AS total_postagens,
    COUNT(c.id_curtida) AS curtidas_recebidas
FROM usuario u
LEFT JOIN postagem p
    ON u.id_usuario = p.id_usuario
LEFT JOIN curtida c
    ON c.id_postagem = p.id_postagem
GROUP BY
    u.id_usuario,
    u.nome
ORDER BY
    curtidas_recebidas DESC,
    total_postagens DESC
";

$result = $conn->query($sql);

$usuarios = [];

while ($row = $result->fetch_assoc()) {
    $row['id_usuario'] = intval($row['id_usuario']);
    $row['total_postagens'] = intval($row['total_postagens']);
    $row['curtidas_recebidas'] = intval($row['curtidas_recebidas']);

    $usuarios[] = $row;
}

echo json_encode(
    $usuarios,
    JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
);
?>