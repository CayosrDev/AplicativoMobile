<?php
include 'conexao.php';
header('Content-Type: application/json; charset=utf-8');

$id_postagem = intval($_GET['id_postagem']);

$sql = "
SELECT 
    cp.id_comentario,
    cp.id_postagem,
    u.nome AS usuario,
    cp.comentario,
    cp.data_comentario
FROM comentario_postagem cp
JOIN usuario u ON cp.id_usuario = u.id_usuario
WHERE cp.id_postagem = ?
ORDER BY cp.data_comentario ASC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_postagem);
$stmt->execute();

$result = $stmt->get_result();
$dados = [];

while ($row = $result->fetch_assoc()) {
    $dados[] = $row;
}

echo json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>