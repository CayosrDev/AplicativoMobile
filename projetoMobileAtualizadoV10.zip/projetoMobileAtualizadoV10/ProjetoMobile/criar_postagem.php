<?php
include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

if (
    !isset($_GET['id_usuario']) ||
    !isset($_GET['id_musica']) ||
    !isset($_GET['comentario'])
) {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "Dados obrigatórios"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$id_usuario = intval($_GET['id_usuario']);
$id_musica = intval($_GET['id_musica']);
$comentario = $_GET['comentario'];

$sql = "
INSERT INTO postagem (id_usuario, id_musica, comentario)
VALUES (?, ?, ?)
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("iis", $id_usuario, $id_musica, $comentario);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "ok",
        "mensagem" => "Postagem criada"
    ], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode([
        "status" => "erro",
        "mensagem" => $stmt->error
    ], JSON_UNESCAPED_UNICODE);
}
?>