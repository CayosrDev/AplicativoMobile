package com.example.aplicativomusicamobile

data class MinhaPostagem(
    val id_postagem: Int,
    val musica: String,
    val comentario: String,
    val curtidas: Int
)