package com.example.aplicativomusicamobile

data class HomeSection(
    val titulo: String,
    val musicas: List<MusicaDeezer>
)