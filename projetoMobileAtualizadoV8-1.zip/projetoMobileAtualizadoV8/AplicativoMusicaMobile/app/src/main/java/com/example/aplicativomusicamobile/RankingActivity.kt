package com.example.aplicativomusicamobile

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.content.Intent
import com.google.android.material.bottomnavigation.BottomNavigationView

class RankingActivity : AppCompatActivity() {

    private lateinit var recyclerLista: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_ranking)

        recyclerLista = findViewById(R.id.recyclerLista)

        recyclerLista.layoutManager =
            LinearLayoutManager(this)

        RetrofitClient.api.ranking()
            .enqueue(object : Callback<List<Ranking>> {

                override fun onResponse(
                    call: Call<List<Ranking>>,
                    response: Response<List<Ranking>>
                ) {

                    val ranking = response.body() ?: emptyList()

                    val lista = ranking.mapIndexed { index, item ->

                        "🏆 #${index + 1} • ${item.nome} • ${item.total_postagens} postagens"

                    }

                    recyclerLista.adapter =
                        TextItemAdapter(lista)
                }

                override fun onFailure(
                    call: Call<List<Ranking>>,
                    t: Throwable
                ) {

                    recyclerLista.adapter =
                        TextItemAdapter(
                            listOf(
                                "Erro: ${t.message}"
                            )
                        )
                }
            })
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        bottomNav.selectedItemId = R.id.nav_post

        bottomNav.setOnItemSelectedListener {

            when(it.itemId){

                R.id.nav_home -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    true
                }

                R.id.nav_search -> {
                    startActivity(Intent(this, SearchActivity::class.java))
                    true
                }

                R.id.nav_post -> {
                    true
                }

                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }

                else -> false
            }
        }
    }

}