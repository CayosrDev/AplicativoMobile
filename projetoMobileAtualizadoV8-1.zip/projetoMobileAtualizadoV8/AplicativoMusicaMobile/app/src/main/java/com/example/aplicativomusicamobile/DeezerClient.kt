package com.example.aplicativomusicamobile

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object DeezerClient {

    private const val BASE_URL = "https://api.deezer.com/"

    val api: DeezerApi by lazy {

        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(DeezerApi::class.java)
    }
}