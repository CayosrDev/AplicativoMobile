package com.example.aplicativomusicamobile

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class MusicaAdapter(
    private val lista: List<MusicaDeezer>,
    private val onClick: ((MusicaDeezer) -> Unit)? = null
) : RecyclerView.Adapter<MusicaAdapter.MusicaViewHolder>() {

    class MusicaViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val imgCapa: ImageView = view.findViewById(R.id.imgCapa)
        val txtTitulo: TextView = view.findViewById(R.id.txtTitulo)
        val txtArtista: TextView = view.findViewById(R.id.txtArtista)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MusicaViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_musica, parent, false)

        return MusicaViewHolder(view)
    }

    override fun getItemCount() = lista.size

    override fun onBindViewHolder(
        holder: MusicaViewHolder,
        position: Int
    ) {

        val musica = lista[position]

        holder.txtTitulo.text = musica.title
        holder.txtArtista.text = musica.artist.name

        Glide.with(holder.itemView.context)
            .load(musica.album.cover_medium)
            .into(holder.imgCapa)

        holder.itemView.setOnClickListener {
            onClick?.invoke(musica)
        }
    }
}