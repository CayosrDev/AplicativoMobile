package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.content.Intent
import com.google.android.material.bottomnavigation.BottomNavigationView
import android.widget.TextView
import android.view.View
import androidx.core.widget.addTextChangedListener

class CreatePostActivity : AppCompatActivity() {

    lateinit var edtMusica: EditText
    lateinit var edtComentario: EditText
    lateinit var btnPostar: Button

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_post)
        
        edtMusica = findViewById(R.id.edtMusica)
        edtComentario = findViewById(R.id.edtComentario)
        btnPostar = findViewById(R.id.btnPostar)
        val txtContador = findViewById<TextView>(R.id.txtContador)

        edtComentario.addTextChangedListener {

            txtContador.text =
                "${edtComentario.text.length}/200"
        }

        btnPostar.setOnClickListener {

            val nomeMusica = edtMusica.text.toString()
            val comentario = edtComentario.text.toString()

            RetrofitClient.api.buscarIdMusica(nomeMusica)
                .enqueue(object : Callback<MusicaId> {

                    override fun onResponse(
                        call: Call<MusicaId>,
                        response: Response<MusicaId>
                    ) {

                        val musica = response.body()

                        if (musica != null) {

                            RetrofitClient.api.criarPostagem(
                                UsuarioSession.idUsuario,
                                musica.id_musica,
                                comentario
                            ).enqueue(object : Callback<Resposta> {

                                override fun onResponse(
                                    call: Call<Resposta>,
                                    response: Response<Resposta>
                                ) {

                                    Toast.makeText(
                                        this@CreatePostActivity,
                                        "Postagem criada",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }

                                override fun onFailure(
                                    call: Call<Resposta>,
                                    t: Throwable
                                ) {

                                    Toast.makeText(
                                        this@CreatePostActivity,
                                        t.message,
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            })

                        } else {

                            Toast.makeText(
                                this@CreatePostActivity,
                                "Música não encontrada",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    override fun onFailure(
                        call: Call<MusicaId>,
                        t: Throwable
                    ) {

                        Toast.makeText(
                            this@CreatePostActivity,
                            t.message,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                })
        }
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        bottomNav.selectedItemId = R.id.nav_post

        bottomNav.setOnItemSelectedListener {

            when(it.itemId){

                R.id.nav_home -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_search -> {
                    startActivity(Intent(this, SearchActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_post -> {
                    startActivity(Intent(this, SearchActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                else -> false
            }
        }
        window.decorView.viewTreeObserver.addOnGlobalLayoutListener {

            val rect = android.graphics.Rect()
            window.decorView.getWindowVisibleDisplayFrame(rect)

            val screenHeight = window.decorView.height
            val keypadHeight = screenHeight - rect.bottom

            if (keypadHeight > screenHeight * 0.15) {
                bottomNav.visibility = View.GONE
            } else {
                bottomNav.visibility = View.VISIBLE
            }
        }
    }
}




