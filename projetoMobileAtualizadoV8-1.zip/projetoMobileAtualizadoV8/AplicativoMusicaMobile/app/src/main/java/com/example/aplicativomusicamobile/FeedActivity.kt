package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.content.Intent
import com.google.android.material.bottomnavigation.BottomNavigationView

class FeedActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: FeedAdapter

    private val usuarioAtualId = 1 // trocar depois pelo login

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_feed)

        recyclerView = findViewById(R.id.recyclerFeed)
        recyclerView.layoutManager = LinearLayoutManager(this)

        adapter = FeedAdapter(emptyList()) { post ->
            RetrofitClient.api.curtir(usuarioAtualId, post.id_postagem)
                .enqueue(object : Callback<Resposta> {
                    override fun onResponse(call: Call<Resposta>, response: Response<Resposta>) {
                        val msg = response.body()?.mensagem ?: "Sem resposta"
                        Toast.makeText(this@FeedActivity, msg, Toast.LENGTH_SHORT).show()
                        carregarFeed()
                    }

                    override fun onFailure(call: Call<Resposta>, t: Throwable) {
                        Toast.makeText(this@FeedActivity, "Erro: ${t.message}", Toast.LENGTH_SHORT).show()
                    }
                })
        }

        recyclerView.adapter = adapter
        carregarFeed()

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        bottomNav.selectedItemId = R.id.nav_post

        bottomNav.setOnItemSelectedListener {

            when(it.itemId){

                R.id.nav_home -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    true
                }

                R.id.nav_search -> {
                    startActivity(Intent(this, SearchActivity::class.java))
                    true
                }

                R.id.nav_post -> {
                    true
                }

                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    true
                }

                else -> false
            }
        }
    }

    private fun carregarFeed() {
        RetrofitClient.api.feed().enqueue(object : Callback<List<FeedPost>> {
            override fun onResponse(call: Call<List<FeedPost>>, response: Response<List<FeedPost>>) {
                val lista = response.body() ?: emptyList()
                adapter.atualizar(lista)
            }

            override fun onFailure(call: Call<List<FeedPost>>, t: Throwable) {
                Toast.makeText(this@FeedActivity, "Erro: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}