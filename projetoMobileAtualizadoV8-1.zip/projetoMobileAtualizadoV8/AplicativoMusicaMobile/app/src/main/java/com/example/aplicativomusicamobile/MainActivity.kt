package com.example.aplicativomusicamobile

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.widget.Toast


class MainActivity : AppCompatActivity() {

    private lateinit var txtUsuario: TextView
    private lateinit var bottomNav: BottomNavigationView

    private lateinit var recyclerBrasil: RecyclerView
    private lateinit var recyclerMundo: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtUsuario = findViewById(R.id.txtUsuario)
        bottomNav = findViewById(R.id.bottomNav)

        recyclerBrasil = findViewById(R.id.recyclerBrasil)
        recyclerMundo = findViewById(R.id.recyclerMundo)

        recyclerBrasil.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        recyclerMundo.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        txtUsuario.text = "Bem vindo, ${UsuarioSession.nomeUsuario}"

        carregarTopBrasil()
        carregarTopMundo()

        bottomNav.selectedItemId = R.id.nav_home

        bottomNav.setOnItemSelectedListener {

            when (it.itemId) {

                R.id.nav_home -> true

                R.id.nav_search -> {
                    startActivity(Intent(this, SearchActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_post -> {
                    startActivity(Intent(this, CreatePostActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                else -> false
            }
        }
    }

    private fun carregarTopBrasil() {

        DeezerClient.api.topBrasil()
            .enqueue(object : Callback<DeezerResponse> {

                override fun onResponse(
                    call: Call<DeezerResponse>,
                    response: Response<DeezerResponse>
                ) {

                    response.body()?.let {

                        recyclerBrasil.adapter =
                            MusicaAdapter(it.data.take(10)) { musica ->

                                Toast.makeText(
                                    this@MainActivity,
                                    musica.title,
                                    Toast.LENGTH_SHORT
                                ).show()

                            }
                    }
                }

                override fun onFailure(
                    call: Call<DeezerResponse>,
                    t: Throwable
                ) {
                }
            })
    }

    private fun carregarTopMundo() {

        DeezerClient.api.topMundo()
            .enqueue(object : Callback<DeezerResponse> {

                override fun onResponse(
                    call: Call<DeezerResponse>,
                    response: Response<DeezerResponse>
                ) {

                    response.body()?.let {

                        recyclerMundo.adapter =
                            MusicaAdapter(it.data.take(10)) { musica ->

                                Toast.makeText(
                                    this@MainActivity,
                                    musica.title,
                                    Toast.LENGTH_SHORT
                                ).show()

                            }
                    }
                }

                override fun onFailure(
                    call: Call<DeezerResponse>,
                    t: Throwable
                ) {
                }
            })
    }
}