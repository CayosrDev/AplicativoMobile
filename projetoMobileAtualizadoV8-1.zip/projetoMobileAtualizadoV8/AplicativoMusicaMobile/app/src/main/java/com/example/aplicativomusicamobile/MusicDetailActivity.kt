package com.example.aplicativomusicamobile

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide

class MusicDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music_detail)

        val img =
            findViewById<ImageView>(R.id.imgCapa)

        val txtTitulo =
            findViewById<TextView>(R.id.txtTitulo)

        val txtArtista =
            findViewById<TextView>(R.id.txtArtista)

        val btnCriarPost =
            findViewById<Button>(R.id.btnCriarPost)

        val titulo =
            intent.getStringExtra("titulo") ?: ""

        val artista =
            intent.getStringExtra("artista") ?: ""

        val capa =
            intent.getStringExtra("capa") ?: ""

        txtTitulo.text = titulo
        txtArtista.text = artista

        Glide.with(this)
            .load(capa)
            .into(img)

        btnCriarPost.setOnClickListener {

            val intent =
                Intent(
                    this,
                    CreatePostActivity::class.java
                )

            intent.putExtra(
                "nome_musica",
                titulo
            )

            startActivity(intent)
        }
    }
}