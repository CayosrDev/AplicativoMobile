package com.example.aplicativomusicamobile

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface DeezerApi {

    @GET("search")
    fun buscarMusicas(
        @Query("q") query: String
    ): Call<DeezerResponse>

    @GET("chart/0/tracks")
    fun topMundo(): Call<DeezerResponse>

    @GET("search")
    fun topBrasil(
        @Query("q") query: String = "Brasil Top"
    ): Call<DeezerResponse>
}