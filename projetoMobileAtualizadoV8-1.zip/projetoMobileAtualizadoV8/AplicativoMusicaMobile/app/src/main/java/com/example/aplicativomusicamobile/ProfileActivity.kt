package com.example.aplicativomusicamobile

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProfileActivity : AppCompatActivity() {

    private lateinit var txtNome: TextView
    private lateinit var txtEmail: TextView
    private lateinit var txtBio: TextView
    private lateinit var txtPosts: TextView
    private lateinit var txtCurtidas: TextView
    private lateinit var btnEditarPerfil: Button
    private lateinit var btnSair: Button
    private lateinit var recyclerMinhasPostagens: RecyclerView

    private val usuarioAtualId
        get() = UsuarioSession.idUsuario

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        txtNome = findViewById(R.id.txtNome)
        txtEmail = findViewById(R.id.txtEmail)
        txtBio = findViewById(R.id.txtBio)
        txtPosts = findViewById(R.id.txtPosts)
        txtCurtidas = findViewById(R.id.txtCurtidas)
        btnEditarPerfil = findViewById(R.id.btnEditarPerfil)
        btnSair = findViewById(R.id.btnSair)
        recyclerMinhasPostagens = findViewById(R.id.recyclerMinhasPostagens)

        recyclerMinhasPostagens.layoutManager =
            LinearLayoutManager(this)

        btnEditarPerfil.setOnClickListener {
            startActivity(Intent(this, EditProfileActivity::class.java))
        }

        btnSair.setOnClickListener {
            UsuarioSession.idUsuario = 0
            UsuarioSession.nomeUsuario = ""
            UsuarioSession.emailUsuario = ""

            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        configurarMenuInferior()

        carregarPerfil()
        carregarMinhasPostagens()
    }

    override fun onResume() {
        super.onResume()
        carregarPerfil()
        carregarMinhasPostagens()
    }

    private fun carregarPerfil() {
        RetrofitClient.api.perfilUsuario(usuarioAtualId)
            .enqueue(object : Callback<PerfilUsuario> {

                override fun onResponse(
                    call: Call<PerfilUsuario>,
                    response: Response<PerfilUsuario>
                ) {
                    val p = response.body()

                    if (p != null) {
                        txtNome.text = p.nome
                        txtEmail.text = p.email
                        txtBio.text = p.bio ?: "Sem bio"
                        txtPosts.text = p.total_postagens.toString()
                        txtCurtidas.text = p.curtidas_recebidas.toString()

                        UsuarioSession.nomeUsuario = p.nome
                        UsuarioSession.emailUsuario = p.email
                    }
                }

                override fun onFailure(
                    call: Call<PerfilUsuario>,
                    t: Throwable
                ) {
                    Toast.makeText(
                        this@ProfileActivity,
                        "Erro: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }

    private fun carregarMinhasPostagens() {
        RetrofitClient.api.minhasPostagens(usuarioAtualId)
            .enqueue(object : Callback<List<MinhaPostagem>> {

                override fun onResponse(
                    call: Call<List<MinhaPostagem>>,
                    response: Response<List<MinhaPostagem>>
                ) {
                    val lista = response.body() ?: emptyList()

                    recyclerMinhasPostagens.adapter =
                        MinhasPostagensAdapter(lista)
                }

                override fun onFailure(
                    call: Call<List<MinhaPostagem>>,
                    t: Throwable
                ) {
                }
            })
    }

    private fun configurarMenuInferior() {
        val bottomNav =
            findViewById<BottomNavigationView>(R.id.bottomNav)

        bottomNav.selectedItemId = R.id.nav_profile

        bottomNav.setOnItemSelectedListener {

            when (it.itemId) {

                R.id.nav_home -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_search -> {
                    startActivity(Intent(this, SearchActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_post -> {
                    startActivity(Intent(this, CreatePostActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_profile -> true

                else -> false
            }
        }
    }
}