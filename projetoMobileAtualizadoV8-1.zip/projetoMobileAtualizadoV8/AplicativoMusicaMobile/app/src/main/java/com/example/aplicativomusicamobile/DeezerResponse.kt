package com.example.aplicativomusicamobile

data class DeezerResponse(
    val data: List<MusicaDeezer>
)