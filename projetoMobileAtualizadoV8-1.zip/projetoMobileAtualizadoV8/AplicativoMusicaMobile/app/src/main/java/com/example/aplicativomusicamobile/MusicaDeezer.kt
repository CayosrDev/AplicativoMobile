package com.example.aplicativomusicamobile

data class MusicaDeezer(

    val title: String,
    val preview: String,
    val artist: Artist,
    val album: Album

)

data class Artist(
    val name: String
)

data class Album(
    val cover_medium: String
)