package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class EditProfileActivity : AppCompatActivity() {

    private lateinit var edtNome: EditText
    private lateinit var edtBio: EditText
    private lateinit var btnSalvar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        edtNome = findViewById(R.id.edtNome)
        edtBio = findViewById(R.id.edtBio)
        btnSalvar = findViewById(R.id.btnSalvar)

        edtNome.setText(UsuarioSession.nomeUsuario)

        btnSalvar.setOnClickListener {
            val nome = edtNome.text.toString().trim()
            val bio = edtBio.text.toString().trim()

            RetrofitClient.api.editarPerfil(
                UsuarioSession.idUsuario,
                nome,
                bio
            ).enqueue(object : Callback<Resposta> {

                override fun onResponse(
                    call: Call<Resposta>,
                    response: Response<Resposta>
                ) {
                    val resposta = response.body()

                    Toast.makeText(
                        this@EditProfileActivity,
                        resposta?.mensagem ?: "Perfil atualizado",
                        Toast.LENGTH_SHORT
                    ).show()

                    if (resposta?.status == "ok") {
                        UsuarioSession.nomeUsuario = nome
                        finish()
                    }
                }

                override fun onFailure(
                    call: Call<Resposta>,
                    t: Throwable
                ) {
                    Toast.makeText(
                        this@EditProfileActivity,
                        "Erro: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }
    }
}