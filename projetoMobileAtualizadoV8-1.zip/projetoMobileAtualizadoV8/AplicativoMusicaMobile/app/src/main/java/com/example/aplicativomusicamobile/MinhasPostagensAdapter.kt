package com.example.aplicativomusicamobile

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MinhasPostagensAdapter(
    private val lista: List<MinhaPostagem>
) : RecyclerView.Adapter<MinhasPostagensAdapter.ViewHolder>() {

    class ViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        val txtMusica: TextView =
            itemView.findViewById(R.id.txtMusica)

        val txtComentario: TextView =
            itemView.findViewById(R.id.txtComentario)

        val txtCurtidas: TextView =
            itemView.findViewById(R.id.txtCurtidas)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(
                R.layout.item_minha_postagem,
                parent,
                false
            )

        return ViewHolder(view)
    }

    override fun getItemCount() = lista.size

    override fun onBindViewHolder(
        holder: ViewHolder,
        position: Int
    ) {

        val postagem = lista[position]

        holder.txtMusica.text =
            "🎵 ${postagem.musica}"

        holder.txtComentario.text =
            postagem.comentario

        holder.txtCurtidas.text =
            "❤️ ${postagem.curtidas} curtidas"
    }
}