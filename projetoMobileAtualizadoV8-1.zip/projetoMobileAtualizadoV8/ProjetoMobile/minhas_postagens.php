<?php
include 'conexao.php';

$id_usuario = intval($_GET['id_usuario']);

$sql = "
SELECT
    p.id_postagem,
    m.nome AS musica,
    p.comentario,
    COUNT(c.id_curtida) AS curtidas
FROM postagem p
INNER JOIN musica m
    ON p.id_musica = m.id_musica
LEFT JOIN curtida c
    ON p.id_postagem = c.id_postagem
WHERE p.id_usuario = ?
GROUP BY p.id_postagem
ORDER BY p.id_postagem DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();

$result = $stmt->get_result();

$postagens = [];

while($row = $result->fetch_assoc()){
    $postagens[] = $row;
}

echo json_encode($postagens);
?>