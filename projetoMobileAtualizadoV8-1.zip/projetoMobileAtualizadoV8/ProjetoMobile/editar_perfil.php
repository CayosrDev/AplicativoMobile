<?php
include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

if (
    !isset($_GET['id_usuario']) ||
    !isset($_GET['nome']) ||
    !isset($_GET['bio'])
) {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "Dados obrigatórios"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$id_usuario = intval($_GET['id_usuario']);
$nome = $_GET['nome'];
$bio = $_GET['bio'];

$sql = "
UPDATE usuario
SET nome = ?, bio = ?
WHERE id_usuario = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssi", $nome, $bio, $id_usuario);

if ($stmt->execute()) {
    echo json_encode([
        "status" => "ok",
        "mensagem" => "Perfil atualizado"
    ], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode([
        "status" => "erro",
        "mensagem" => "Erro ao atualizar perfil"
    ], JSON_UNESCAPED_UNICODE);
}
?>