package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.content.Intent
import com.google.android.material.bottomnavigation.BottomNavigationView

class ProfileActivity : AppCompatActivity() {

    private lateinit var txtPerfil: TextView
    private val usuarioAtualId
        get() = UsuarioSession.idUsuario

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        txtPerfil = findViewById(R.id.txtPerfil)

        Toast.makeText(
            this,
            "ID: ${UsuarioSession.idUsuario}",
            Toast.LENGTH_SHORT
        ).show()

        RetrofitClient.api.perfilUsuario(usuarioAtualId).enqueue(object : Callback<PerfilUsuario> {
            override fun onResponse(call: Call<PerfilUsuario>, response: Response<PerfilUsuario>) {
                val p = response.body()
                if (p != null) {
                    txtPerfil.text =
                        "👤 ${p.nome}\n\n" +
                                "Email: ${p.email}\n" +
                                "Bio: ${p.bio ?: "Sem bio"}\n\n" +
                                "Postagens: ${p.total_postagens}\n" +
                                "Curtidas recebidas: ${p.curtidas_recebidas}"
                } else {
                    txtPerfil.text = "Perfil vazio"
                }
            }

            override fun onFailure(call: Call<PerfilUsuario>, t: Throwable) {
                Toast.makeText(this@ProfileActivity, "Erro: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        bottomNav.selectedItemId = R.id.nav_profile

        bottomNav.setOnItemSelectedListener {

            when(it.itemId){

                R.id.nav_home -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_search -> {
                    startActivity(Intent(this, SearchActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_post -> {
                    startActivity(Intent(this, SearchActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                else -> false
            }
        }
    }
}