package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.content.Intent
import com.google.android.material.bottomnavigation.BottomNavigationView


class SearchActivity : AppCompatActivity() {

    private lateinit var edtBusca: EditText
    private lateinit var recyclerView: RecyclerView
    private lateinit var btnBuscar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        edtBusca = findViewById(R.id.edtBusca)
        recyclerView = findViewById(R.id.recyclerBusca)
        btnBuscar = findViewById(R.id.btnBuscar)

        recyclerView.layoutManager = LinearLayoutManager(this)

        btnBuscar.setOnClickListener {

            val termo = edtBusca.text.toString().trim()

            if (termo.isEmpty()) {

                Toast.makeText(
                    this,
                    "Digite uma música ou artista",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            DeezerClient.api.buscarMusicas(termo)
                .enqueue(object : Callback<DeezerResponse> {

                    override fun onResponse(
                        call: Call<DeezerResponse>,
                        response: Response<DeezerResponse>
                    ) {

                        if (response.isSuccessful) {

                            val musicas =
                                response.body()?.data ?: emptyList()

                            recyclerView.adapter =
                                MusicaAdapter(musicas)

                        } else {

                            Toast.makeText(
                                this@SearchActivity,
                                "Nenhum resultado encontrado",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    override fun onFailure(
                        call: Call<DeezerResponse>,
                        t: Throwable
                    ) {

                        Toast.makeText(
                            this@SearchActivity,
                            "Erro: ${t.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                })
        }
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)

        bottomNav.selectedItemId = R.id.nav_search

        bottomNav.setOnItemSelectedListener {

            when(it.itemId){

                R.id.nav_home -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_search -> {
                    startActivity(Intent(this, SearchActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_post -> {
                    startActivity(Intent(this, CreatePostActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                else -> false
            }
        }
    }
}