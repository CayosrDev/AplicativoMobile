<?php
include 'conexao.php';

header('Content-Type: application/json');

if (!isset($_GET['id_usuario']) || !isset($_GET['id_postagem'])) {

    echo json_encode([
        "status" => "erro",
        "mensagem" => "Parâmetros obrigatórios"
    ]);

    exit;
}

$id_usuario = intval($_GET['id_usuario']);
$id_postagem = intval($_GET['id_postagem']);

$verifica = "
SELECT * FROM curtida
WHERE id_usuario = $id_usuario
AND id_postagem = $id_postagem
";

$resultado = $conn->query($verifica);

if ($resultado->num_rows > 0) {

    echo json_encode([
        "status" => "erro",
        "mensagem" => "Usuário já curtiu essa postagem"
    ]);

    exit;
}

$sql = "
INSERT INTO curtida(id_usuario, id_postagem)
VALUES($id_usuario, $id_postagem)
";

if($conn->query($sql)) {

    echo json_encode([
        "status" => "ok",
        "mensagem" => "Curtida realizada"
    ]);

} else {

    echo json_encode([
        "status" => "erro",
        "mensagem" => $conn->error
    ]);
}
?>