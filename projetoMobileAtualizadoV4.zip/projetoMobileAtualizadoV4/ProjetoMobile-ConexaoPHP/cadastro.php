<?php

include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

if (
    !isset($_GET['nome']) ||
    !isset($_GET['email']) ||
    !isset($_GET['senha'])
) {

    echo json_encode([
        "status" => "erro",
        "mensagem" => "Dados obrigatórios"
    ]);

    exit;
}

$nome = $_GET['nome'];
$email = $_GET['email'];
$senha = $_GET['senha'];

$verifica = "
SELECT *
FROM usuario
WHERE email = '$email'
";

$result = $conn->query($verifica);

if ($result->num_rows > 0) {

    echo json_encode([
        "status" => "erro",
        "mensagem" => "Email já cadastrado"
    ]);

    exit;
}

$sql = "
INSERT INTO usuario(nome, email, senha)
VALUES('$nome', '$email', '$senha')
";

if ($conn->query($sql)) {

    echo json_encode([
        "status" => "ok",
        "mensagem" => "Usuário cadastrado"
    ]);

} else {

    echo json_encode([
        "status" => "erro",
        "mensagem" => "Erro ao cadastrar"
    ]);
}
?>