<?php
include 'conexao.php';

header('Content-Type: application/json');

$sql = "INSERT INTO postagem (id_usuario, id_musica, comentario)
VALUES (1, 1, 'Teste via app')";

if ($conn->query($sql)) {
    echo json_encode(["status" => "ok", "mensagem" => "Postagem criada"]);
} else {
    echo json_encode(["status" => "erro", "mensagem" => $conn->error]);
}
?>