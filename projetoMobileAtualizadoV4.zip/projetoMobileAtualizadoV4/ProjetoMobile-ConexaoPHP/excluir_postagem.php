<?php
include 'conexao.php';

header('Content-Type: application/json');

if (!isset($_GET['id'])) {
    echo json_encode(["status" => "erro", "mensagem" => "ID não informado"]);
    exit;
}

$id = intval($_GET['id']);

$sql = "DELETE FROM postagem WHERE id_postagem=$id";

if ($conn->query($sql)) {
    if ($conn->affected_rows > 0) {
        echo json_encode(["status" => "ok", "mensagem" => "Postagem excluída"]);
    } else {
        echo json_encode(["status" => "erro", "mensagem" => "ID não encontrado"]);
    }
}
?>