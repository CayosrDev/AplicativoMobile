<?php
include 'conexao.php';

header('Content-Type: application/json');

// Valida ID
if (!isset($_GET['id'])) {
    echo json_encode(["status" => "erro", "mensagem" => "ID não informado"]);
    exit;
}

// Valida comentário
if (!isset($_GET['comentario'])) {
    echo json_encode(["status" => "erro", "mensagem" => "Comentário não informado"]);
    exit;
}

$id = intval($_GET['id']);
$comentario = $conn->real_escape_string($_GET['comentario']);

// SQL
$sql = "UPDATE postagem SET comentario='$comentario' WHERE id_postagem=$id";

if ($conn->query($sql)) {
    if ($conn->affected_rows > 0) {
        echo json_encode(["status" => "ok", "mensagem" => "Postagem atualizada"]);
    } else {
        echo json_encode(["status" => "erro", "mensagem" => "ID não encontrado ou sem alteração"]);
    }
} else {
    echo json_encode(["status" => "erro", "mensagem" => $conn->error]);
}
?>