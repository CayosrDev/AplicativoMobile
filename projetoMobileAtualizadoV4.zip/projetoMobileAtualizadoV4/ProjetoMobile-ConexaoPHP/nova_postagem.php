<?php

include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

if (
    !isset($_GET['id_usuario']) ||
    !isset($_GET['id_musica']) ||
    !isset($_GET['comentario'])
) {

    echo json_encode([
        "status" => "erro",
        "mensagem" => "Dados obrigatórios"
    ]);

    exit;
}

$id_usuario = $_GET['id_usuario'];
$id_musica = $_GET['id_musica'];
$comentario = $_GET['comentario'];

$sql = "
INSERT INTO postagem(
    id_usuario,
    id_musica,
    comentario
)
VALUES(
    '$id_usuario',
    '$id_musica',
    '$comentario'
)
";

if ($conn->query($sql)) {

    echo json_encode([
        "status" => "ok",
        "mensagem" => "Postagem criada"
    ]);

} else {

    echo json_encode([
        "status" => "erro",
        "mensagem" => "Erro ao criar postagem"
    ]);
}
?>