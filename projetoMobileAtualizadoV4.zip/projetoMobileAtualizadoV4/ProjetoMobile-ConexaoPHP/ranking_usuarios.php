<?php

include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

$sql = "
SELECT
    u.nome,
    COUNT(p.id_postagem) AS total_postagens
FROM usuario u
LEFT JOIN postagem p
ON u.id_usuario = p.id_usuario
GROUP BY u.id_usuario
ORDER BY total_postagens DESC
";

$result = $conn->query($sql);

$usuarios = [];

while ($row = $result->fetch_assoc()) {
    $usuarios[] = $row;
}

echo json_encode(
    $usuarios,
    JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
);
?>