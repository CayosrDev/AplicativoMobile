<?php

include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_GET['nome'])) {

    echo json_encode([
        "status" => "erro"
    ]);

    exit;
}

$nome = $_GET['nome'];

$sql = "
SELECT id_musica
FROM musica
WHERE nome LIKE '%$nome%'
LIMIT 1
";

$result = $conn->query($sql);

if ($result->num_rows > 0) {

    $musica = $result->fetch_assoc();

    echo json_encode($musica);

} else {

    echo json_encode([
        "status" => "erro"
    ]);
}
?>