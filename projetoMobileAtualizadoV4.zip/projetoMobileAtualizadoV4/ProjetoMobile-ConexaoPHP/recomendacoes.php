<?php
include 'conexao.php';
header('Content-Type: application/json; charset=utf-8');

$sql = "
SELECT 
    m.id_musica,
    m.nome,
    m.artista,
    COUNT(c.id_curtida) AS curtidas,
    COUNT(DISTINCT p.id_postagem) AS postagens
FROM musica m
LEFT JOIN postagem p ON p.id_musica = m.id_musica
LEFT JOIN curtida c ON c.id_postagem = p.id_postagem
GROUP BY m.id_musica, m.nome, m.artista
ORDER BY curtidas DESC, postagens DESC, m.nome ASC
LIMIT 10
";

$result = $conn->query($sql);
$dados = [];

while ($row = $result->fetch_assoc()) {
    $dados[] = $row;
}

echo json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>