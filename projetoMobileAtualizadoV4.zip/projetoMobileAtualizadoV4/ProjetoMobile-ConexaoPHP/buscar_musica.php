<?php
include 'conexao.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_GET['q']) || trim($_GET['q']) === '') {
    echo json_encode([
        "erro" => "Informe um termo de busca"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$q = trim($_GET['q']);
$like = "%$q%";

$sql = "
SELECT 
    m.id_musica,
    m.nome,
    m.artista,
    g.nome AS genero
FROM musica m
LEFT JOIN genero g ON m.id_genero = g.id_genero
WHERE m.nome LIKE ?
   OR m.artista LIKE ?
   OR g.nome LIKE ?
ORDER BY m.nome ASC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $like, $like, $like);
$stmt->execute();

$result = $stmt->get_result();
$dados = [];

while ($row = $result->fetch_assoc()) {
    $dados[] = $row;
}

echo json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>