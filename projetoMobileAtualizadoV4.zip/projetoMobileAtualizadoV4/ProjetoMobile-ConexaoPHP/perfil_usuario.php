<?php
include 'conexao.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_GET['id_usuario'])) {
    echo json_encode([
        "erro" => "ID do usuário não informado"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$id_usuario = intval($_GET['id_usuario']);

$sql = "
SELECT 
    u.id_usuario,
    u.nome,
    u.email,
    u.bio,
    COALESCE(COUNT(DISTINCT p.id_postagem), 0) AS total_postagens,
    COALESCE((
        SELECT COUNT(*)
        FROM curtida c
        JOIN postagem p2 ON c.id_postagem = p2.id_postagem
        WHERE p2.id_usuario = u.id_usuario
    ), 0) AS curtidas_recebidas
FROM usuario u
LEFT JOIN postagem p ON p.id_usuario = u.id_usuario
WHERE u.id_usuario = ?
GROUP BY u.id_usuario, u.nome, u.email, u.bio
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();

$result = $stmt->get_result();
$perfil = $result->fetch_assoc();

if (!$perfil) {
    echo json_encode([
        "erro" => "Usuário não encontrado"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode($perfil, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>