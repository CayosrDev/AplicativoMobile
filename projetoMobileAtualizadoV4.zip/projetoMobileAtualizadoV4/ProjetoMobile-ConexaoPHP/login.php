<?php
include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_GET['email']) || !isset($_GET['senha'])) {

    echo json_encode([
        "status" => "erro",
        "mensagem" => "Dados obrigatórios"
    ]);

    exit;
}

$email = $_GET['email'];
$senha = $_GET['senha'];

$sql = "
SELECT *
FROM usuario
WHERE email = '$email'
AND senha = '$senha'
";

$result = $conn->query($sql);

if ($result->num_rows > 0) {

    $usuario = $result->fetch_assoc();

    echo json_encode([
        "status" => "ok",
        "id_usuario" => $usuario['id_usuario'],
        "nome" => $usuario['nome'],
        "email" => $usuario['email']
    ], JSON_UNESCAPED_UNICODE);

} else {

    echo json_encode([
        "status" => "erro",
        "mensagem" => "Login inválido"
    ]);
}
?>