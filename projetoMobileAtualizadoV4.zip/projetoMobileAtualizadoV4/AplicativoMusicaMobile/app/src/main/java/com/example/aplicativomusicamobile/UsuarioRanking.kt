package com.example.aplicativomusicamobile

data class UsuarioRanking(
    val id_usuario: Int,
    val usuario: String,
    val total_postagens: Int,
    val curtidas_recebidas: Int
)