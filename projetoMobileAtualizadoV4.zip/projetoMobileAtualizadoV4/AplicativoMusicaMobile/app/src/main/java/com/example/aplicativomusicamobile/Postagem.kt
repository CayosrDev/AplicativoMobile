package com.example.aplicativomusicamobile

data class Postagem(
    val id_postagem: Int,
    val usuario: String,
    val musica: String,
    val artista: String,
    val comentario: String
)
