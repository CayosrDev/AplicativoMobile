package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SearchActivity : AppCompatActivity() {

    private lateinit var edtBusca: EditText
    private lateinit var recyclerView: RecyclerView
    private lateinit var btnBuscar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)

        edtBusca = findViewById(R.id.edtBusca)
        recyclerView = findViewById(R.id.recyclerBusca)
        btnBuscar = findViewById(R.id.btnBuscar)

        recyclerView.layoutManager = LinearLayoutManager(this)

        btnBuscar.setOnClickListener {
            val termo = edtBusca.text.toString().trim()
            if (termo.isEmpty()) {
                Toast.makeText(this, "Digite um termo", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            RetrofitClient.api.buscarMusica(termo).enqueue(object : Callback<List<MusicaBusca>> {
                override fun onResponse(call: Call<List<MusicaBusca>>, response: Response<List<MusicaBusca>>) {
                    val lista = response.body().orEmpty().map {
                        "🎵 ${it.nome} - ${it.artista} ${if (!it.genero.isNullOrBlank()) "• ${it.genero}" else ""}"
                    }
                    recyclerView.adapter = TextItemAdapter(lista)
                }

                override fun onFailure(call: Call<List<MusicaBusca>>, t: Throwable) {
                    Toast.makeText(this@SearchActivity, "Erro: ${t.message}", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }
}