package com.example.aplicativomusicamobile

data class MusicaId(
    val id_musica: Int
)