package com.example.aplicativomusicamobile

data class MusicaBusca(
    val id_musica: Int,
    val nome: String,
    val artista: String,
    val genero: String?
)
