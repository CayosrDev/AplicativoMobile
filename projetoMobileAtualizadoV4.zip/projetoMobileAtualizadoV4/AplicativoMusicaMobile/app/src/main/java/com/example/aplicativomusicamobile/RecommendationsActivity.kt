package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RecommendationsActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simple_list)

        recyclerView = findViewById(R.id.recyclerLista)
        recyclerView.layoutManager = LinearLayoutManager(this)

        RetrofitClient.api.recomendacoes().enqueue(object : Callback<List<Recomendacao>> {
            override fun onResponse(call: Call<List<Recomendacao>>, response: Response<List<Recomendacao>>) {
                val lista = response.body().orEmpty().map {
                    " ${it.nome} - ${it.artista}\nCurtidas: ${it.curtidas} | Postagens: ${it.postagens}"
                }
                recyclerView.adapter = TextItemAdapter(lista)
            }

            override fun onFailure(call: Call<List<Recomendacao>>, t: Throwable) {
                Toast.makeText(this@RecommendationsActivity, "Erro: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}