package com.example.aplicativomusicamobile

data class Ranking(
    val nome: String,
    val total_postagens: Int
)