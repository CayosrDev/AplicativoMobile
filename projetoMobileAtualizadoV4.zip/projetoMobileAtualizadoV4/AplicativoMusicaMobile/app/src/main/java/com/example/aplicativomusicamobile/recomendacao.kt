package com.example.aplicativomusicamobile

data class Recomendacao(
    val id_musica: Int,
    val nome: String,
    val artista: String,
    val curtidas: Int,
    val postagens: Int
)
