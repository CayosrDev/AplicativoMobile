package com.example.aplicativomusicamobile

object UsuarioSession {

    var idUsuario: Int = 0
    var nomeUsuario: String = ""
    var emailUsuario: String = ""
}