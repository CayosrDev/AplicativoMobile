package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RankingActivity : AppCompatActivity() {

    lateinit var txtRanking: TextView

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ranking)

        txtRanking = findViewById(R.id.txtRanking)

        RetrofitClient.api.ranking()
            .enqueue(object : Callback<List<Ranking>> {

                override fun onResponse(
                    call: Call<List<Ranking>>,
                    response: Response<List<Ranking>>
                ) {

                    val ranking = response.body()

                    var texto = "🏆 Ranking\\n\\n"

                    ranking?.forEach {

                        texto +=
                            "${it.nome} - ${it.total_postagens} postagens\\n"
                    }

                    txtRanking.text = texto
                }

                override fun onFailure(
                    call: Call<List<Ranking>>,
                    t: Throwable
                ) {

                    txtRanking.text = t.message
                }
            })
    }
}