package com.example.aplicativomusicamobile

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TextItemAdapter(private val itens: List<String>) :
    RecyclerView.Adapter<TextItemAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val txtLinha: TextView = view.findViewById(R.id.txtLinha)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_texto, parent, false)
        return VH(view)
    }

    override fun getItemCount(): Int = itens.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.txtLinha.text = itens[position]
    }
}