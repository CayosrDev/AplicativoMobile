package com.example.aplicativomusicamobile

data class FeedPost(
    val id_postagem: Int,
    val usuario: String,
    val musica: String,
    val artista: String,
    val comentario: String,
    val latitude: String?,
    val longitude: String?,
    val data_postagem: String?,
    val curtidas: Int
)
