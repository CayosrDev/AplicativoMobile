package com.example.aplicativomusicamobile

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FeedAdapter(
    private var itens: List<FeedPost>,
    private val onCurtir: (FeedPost) -> Unit
) : RecyclerView.Adapter<FeedAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val txtUsuario: TextView = view.findViewById(R.id.txtUsuario)
        val txtMusica: TextView = view.findViewById(R.id.txtMusica)
        val txtComentario: TextView = view.findViewById(R.id.txtComentario)
        val txtCurtidas: TextView = view.findViewById(R.id.txtCurtidas)
        val btnCurtir: Button = view.findViewById(R.id.btnCurtir)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_feed, parent, false)
        return VH(view)
    }

    override fun getItemCount(): Int = itens.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val post = itens[position]

        holder.txtUsuario.text = post.usuario
        holder.txtMusica.text = " ${post.musica} - ${post.artista}"
        holder.txtComentario.text = " ${post.comentario}"
        holder.txtCurtidas.text = "${post.curtidas}"

        holder.btnCurtir.setOnClickListener {
            onCurtir(post)
        }
    }

    fun atualizar(novaLista: List<FeedPost>) {
        itens = novaLista
        notifyDataSetChanged()
    }
}