package com.example.aplicativomusicamobile

data class PerfilUsuario(
    val id_usuario: Int,
    val nome: String,
    val email: String,
    val bio: String?,
    val total_postagens: Int,
    val curtidas_recebidas: Int
)
