package com.example.aplicativomusicamobile

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txtUsuario = findViewById<TextView>(R.id.txtUsuario)

        txtUsuario.text = "Olá, ${UsuarioSession.nomeUsuario} 👋"

        findViewById<MaterialCardView>(R.id.cardFeed).setOnClickListener {
            startActivity(Intent(this, FeedActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardBusca).setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardRecomendacoes).setOnClickListener {
            startActivity(Intent(this, RecommendationsActivity::class.java))
        }

        findViewById<MaterialCardView>(R.id.cardPerfil).setOnClickListener {
            startActivity(Intent(this, ProfileActivity::class.java))
        }
        findViewById<MaterialCardView>(R.id.cardNovaPostagem).setOnClickListener {
            startActivity(Intent(this, CreatePostActivity::class.java))
        }
    }
}