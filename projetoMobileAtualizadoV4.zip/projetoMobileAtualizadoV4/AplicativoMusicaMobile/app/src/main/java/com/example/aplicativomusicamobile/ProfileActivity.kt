package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProfileActivity : AppCompatActivity() {

    private lateinit var txtPerfil: TextView
    private val usuarioAtualId = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        txtPerfil = findViewById(R.id.txtPerfil)

        RetrofitClient.api.perfilUsuario(usuarioAtualId).enqueue(object : Callback<PerfilUsuario> {
            override fun onResponse(call: Call<PerfilUsuario>, response: Response<PerfilUsuario>) {
                val p = response.body()
                if (p != null) {
                    txtPerfil.text =
                        "👤 ${p.nome}\n\n" +
                                "Email: ${p.email}\n" +
                                "Bio: ${p.bio ?: "Sem bio"}\n\n" +
                                "Postagens: ${p.total_postagens}\n" +
                                "Curtidas recebidas: ${p.curtidas_recebidas}"
                } else {
                    txtPerfil.text = "Perfil vazio"
                }
            }

            override fun onFailure(call: Call<PerfilUsuario>, t: Throwable) {
                Toast.makeText(this@ProfileActivity, "Erro: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}