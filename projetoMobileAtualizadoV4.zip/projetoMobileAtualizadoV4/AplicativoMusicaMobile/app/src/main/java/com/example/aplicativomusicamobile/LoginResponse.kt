package com.example.aplicativomusicamobile

data class LoginResponse(
    val status: String,
    val id_usuario: Int?,
    val nome: String?,
    val email: String?,
    val mensagem: String?
)