package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CreatePostActivity : AppCompatActivity() {

    lateinit var edtMusica: EditText
    lateinit var edtComentario: EditText
    lateinit var btnPostar: Button

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_post)
        
        edtMusica = findViewById(R.id.edtMusica)
        edtComentario = findViewById(R.id.edtComentario)
        btnPostar = findViewById(R.id.btnPostar)

        btnPostar.setOnClickListener {

            val nomeMusica = edtMusica.text.toString()
            val comentario = edtComentario.text.toString()

            RetrofitClient.api.buscarIdMusica(nomeMusica)
                .enqueue(object : Callback<MusicaId> {

                    override fun onResponse(
                        call: Call<MusicaId>,
                        response: Response<MusicaId>
                    ) {

                        val musica = response.body()

                        if (musica != null) {

                            RetrofitClient.api.criarPostagem(
                                UsuarioSession.idUsuario,
                                musica.id_musica,
                                comentario
                            ).enqueue(object : Callback<Resposta> {

                                override fun onResponse(
                                    call: Call<Resposta>,
                                    response: Response<Resposta>
                                ) {

                                    Toast.makeText(
                                        this@CreatePostActivity,
                                        "Postagem criada",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }

                                override fun onFailure(
                                    call: Call<Resposta>,
                                    t: Throwable
                                ) {

                                    Toast.makeText(
                                        this@CreatePostActivity,
                                        t.message,
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            })

                        } else {

                            Toast.makeText(
                                this@CreatePostActivity,
                                "Música não encontrada",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }

                    override fun onFailure(
                        call: Call<MusicaId>,
                        t: Throwable
                    ) {

                        Toast.makeText(
                            this@CreatePostActivity,
                            t.message,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                })
        }
    }
}




