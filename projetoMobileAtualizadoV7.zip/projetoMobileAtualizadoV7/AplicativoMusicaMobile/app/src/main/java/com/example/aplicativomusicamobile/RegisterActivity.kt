package com.example.aplicativomusicamobile

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterActivity : AppCompatActivity() {

    lateinit var edtNome: EditText
    lateinit var edtEmail: EditText
    lateinit var edtSenha: EditText
    lateinit var btnCadastrar: Button
    lateinit var txtLogin: TextView

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        edtNome = findViewById(R.id.edtNome)
        edtEmail = findViewById(R.id.edtEmail)
        edtSenha = findViewById(R.id.edtSenha)

        btnCadastrar = findViewById(R.id.btnCadastrar)
        txtLogin = findViewById(R.id.txtLogin)

        btnCadastrar.setOnClickListener {

            val nome = edtNome.text.toString()
            val email = edtEmail.text.toString()
            val senha = edtSenha.text.toString()

            RetrofitClient.api.cadastro(nome, email, senha)
                .enqueue(object : Callback<Resposta> {

                    override fun onResponse(
                        call: Call<Resposta>,
                        response: Response<Resposta>
                    ) {

                        val resposta = response.body()

                        Toast.makeText(
                            this@RegisterActivity,
                            resposta?.mensagem,
                            Toast.LENGTH_SHORT
                        ).show()

                        if (resposta?.status == "ok") {

                            startActivity(
                                Intent(
                                    this@RegisterActivity,
                                    LoginActivity::class.java
                                )
                            )

                            finish()
                        }
                    }

                    override fun onFailure(
                        call: Call<Resposta>,
                        t: Throwable
                    ) {

                        Toast.makeText(
                            this@RegisterActivity,
                            t.message,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                })
        }

        txtLogin.setOnClickListener {

            startActivity(
                Intent(
                    this,
                    LoginActivity::class.java
                )
            )
        }
    }
}