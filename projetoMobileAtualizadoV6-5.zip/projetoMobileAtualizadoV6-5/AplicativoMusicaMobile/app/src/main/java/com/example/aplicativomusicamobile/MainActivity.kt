package com.example.aplicativomusicamobile

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var txtUsuario: TextView
    private lateinit var bottomNav: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtUsuario = findViewById(R.id.txtUsuario)
        bottomNav = findViewById(R.id.bottomNav)

        txtUsuario.text = "Bem vindo, ${UsuarioSession.nomeUsuario}"

        bottomNav.selectedItemId = R.id.nav_home

        bottomNav.setOnItemSelectedListener {

            when (it.itemId) {

                R.id.nav_home -> {
                    true
                }

                R.id.nav_search -> {
                    startActivity(
                        Intent(
                            this,
                            SearchActivity::class.java
                        )
                    )
                    true
                }

                R.id.nav_post -> {
                    startActivity(
                        Intent(
                            this,
                            CreatePostActivity::class.java
                        )
                    )
                    true
                }

                R.id.nav_profile -> {
                    startActivity(
                        Intent(
                            this,
                            ProfileActivity::class.java
                        )
                    )
                    true
                }

                else -> false
            }
        }
    }
}