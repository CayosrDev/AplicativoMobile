-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 19/05/2026 às 01:37
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `musicmap`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `curtida`
--

CREATE TABLE `curtida` (
  `id_curtida` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_postagem` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `curtida`
--

INSERT INTO `curtida` (`id_curtida`, `id_usuario`, `id_postagem`) VALUES
(1, 1, 2),
(2, 1, 3),
(3, 2, 1),
(4, 2, 5),
(5, 3, 1),
(6, 3, 2),
(7, 3, 4),
(8, 4, 1),
(9, 4, 2),
(10, 4, 3);

-- --------------------------------------------------------

--
-- Estrutura para tabela `genero`
--

CREATE TABLE `genero` (
  `id_genero` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `genero`
--

INSERT INTO `genero` (`id_genero`, `nome`) VALUES
(1, 'Hip Hop'),
(2, 'Neo Soul'),
(3, 'Rock'),
(4, 'Jazz'),
(5, 'MPB'),
(6, 'Indie'),
(7, 'R&B');

-- --------------------------------------------------------

--
-- Estrutura para tabela `musica`
--

CREATE TABLE `musica` (
  `id_musica` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `artista` varchar(150) NOT NULL,
  `id_genero` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `musica`
--

INSERT INTO `musica` (`id_musica`, `nome`, `artista`, `id_genero`) VALUES
(1, 'Untitled (How Does It Feel)', 'D Angelo', 7),
(2, 'Devil In A New Dress', 'Kanye West', 1),
(3, 'Magnolia', 'Songs: Ohia', 6),
(4, 'Come Away With Me', 'Norah Jones', 4),
(5, 'Aquarela', 'Toquinho', 5),
(6, 'Nutshell', 'Alice In Chains', 3),
(7, 'Redbone', 'Childish Gambino', 7),
(8, 'C.R.E.A.M.', 'Wu-Tang Clan', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `postagem`
--

CREATE TABLE `postagem` (
  `id_postagem` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_musica` int(11) NOT NULL,
  `comentario` text DEFAULT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `data_postagem` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `postagem`
--

INSERT INTO `postagem` (`id_postagem`, `id_usuario`, `id_musica`, `comentario`, `latitude`, `longitude`, `data_postagem`) VALUES
(1, 1, 1, 'Essa música é absurda de boa', -15.7938890, -47.8827780, '2026-05-18 23:08:21'),
(2, 2, 2, 'Produção impecável', -15.7940000, -47.8830000, '2026-05-18 23:08:21'),
(3, 3, 3, 'Descobri recentemente e adorei', -15.7920000, -47.8800000, '2026-05-18 23:08:21'),
(4, 4, 6, 'Uma das melhores acústicas já feitas', -15.7910000, -47.8810000, '2026-05-18 23:08:21'),
(5, 1, 7, 'Vibe perfeita pra noite', -15.7900000, -47.8820000, '2026-05-18 23:08:21'),
(6, 2, 4, 'Jazz muito confortável', -15.7890000, -47.8830000, '2026-05-18 23:08:21');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `bio` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nome`, `email`, `senha`, `bio`) VALUES
(1, 'Ana', 'ana@email.com', '123456', 'Apaixonada por música alternativa'),
(2, 'Carlos', 'carlos@email.com', '123456', 'Colecionador de vinil'),
(3, 'Julia', 'julia@email.com', '123456', 'Curte indie e jazz'),
(4, 'Pedro', 'pedro@email.com', '123456', 'Músico e produtor');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `curtida`
--
ALTER TABLE `curtida`
  ADD PRIMARY KEY (`id_curtida`),
  ADD UNIQUE KEY `uk_usuario_postagem` (`id_usuario`,`id_postagem`),
  ADD KEY `fk_curtida_postagem` (`id_postagem`);

--
-- Índices de tabela `genero`
--
ALTER TABLE `genero`
  ADD PRIMARY KEY (`id_genero`);

--
-- Índices de tabela `musica`
--
ALTER TABLE `musica`
  ADD PRIMARY KEY (`id_musica`),
  ADD KEY `fk_musica_genero` (`id_genero`);

--
-- Índices de tabela `postagem`
--
ALTER TABLE `postagem`
  ADD PRIMARY KEY (`id_postagem`),
  ADD KEY `fk_postagem_usuario` (`id_usuario`),
  ADD KEY `fk_postagem_musica` (`id_musica`);

--
-- Índices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `curtida`
--
ALTER TABLE `curtida`
  MODIFY `id_curtida` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `genero`
--
ALTER TABLE `genero`
  MODIFY `id_genero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `musica`
--
ALTER TABLE `musica`
  MODIFY `id_musica` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `postagem`
--
ALTER TABLE `postagem`
  MODIFY `id_postagem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `curtida`
--
ALTER TABLE `curtida`
  ADD CONSTRAINT `fk_curtida_postagem` FOREIGN KEY (`id_postagem`) REFERENCES `postagem` (`id_postagem`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_curtida_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE;

--
-- Restrições para tabelas `musica`
--
ALTER TABLE `musica`
  ADD CONSTRAINT `fk_musica_genero` FOREIGN KEY (`id_genero`) REFERENCES `genero` (`id_genero`) ON DELETE SET NULL;

--
-- Restrições para tabelas `postagem`
--
ALTER TABLE `postagem`
  ADD CONSTRAINT `fk_postagem_musica` FOREIGN KEY (`id_musica`) REFERENCES `musica` (`id_musica`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_postagem_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
