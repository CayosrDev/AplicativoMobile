<?php
include 'conexao.php';

header('Content-Type: application/json');

$sql = "
SELECT
    p.id_postagem,
    u.nome AS usuario,
    m.nome AS musica,
    m.artista,
    p.comentario
FROM postagem p
JOIN usuario u ON p.id_usuario = u.id_usuario
JOIN musica m ON p.id_musica = m.id_musica
ORDER BY p.data_postagem DESC
";

$result = $conn->query($sql);

$dados = [];

while($row = $result->fetch_assoc()) {
    $dados[] = $row;
}

echo json_encode($dados);
?>