-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 09/05/2026 às 06:37
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `musicmap`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `comentario`
--

CREATE TABLE `comentario` (
  `id_comentario` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_postagem` int(11) NOT NULL,
  `comentario` text NOT NULL,
  `data_comentario` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `curtida`
--

CREATE TABLE `curtida` (
  `id_curtida` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_postagem` int(11) NOT NULL,
  `data_curtida` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `curtida`
--

INSERT INTO `curtida` (`id_curtida`, `id_usuario`, `id_postagem`, `data_curtida`) VALUES
(18, 1, 16, '2026-05-09 01:22:18'),
(19, 2, 16, '2026-05-09 01:22:18'),
(20, 3, 16, '2026-05-09 01:22:18'),
(21, 4, 16, '2026-05-09 01:22:18'),
(22, 1, 17, '2026-05-09 01:22:18'),
(23, 3, 17, '2026-05-09 01:22:18'),
(24, 2, 18, '2026-05-09 01:22:18'),
(25, 4, 18, '2026-05-09 01:22:18'),
(26, 5, 18, '2026-05-09 01:22:18'),
(27, 1, 19, '2026-05-09 01:22:18'),
(28, 2, 19, '2026-05-09 01:22:18'),
(29, 5, 20, '2026-05-09 01:22:18'),
(30, 3, 21, '2026-05-09 01:22:18'),
(31, 4, 21, '2026-05-09 01:22:18'),
(32, 1, 22, '2026-05-09 01:22:18'),
(33, 2, 23, '2026-05-09 01:22:18'),
(34, 5, 23, '2026-05-09 01:22:18'),
(36, 5, 17, '2026-05-09 01:29:24');

-- --------------------------------------------------------

--
-- Estrutura para tabela `genero`
--

CREATE TABLE `genero` (
  `id_genero` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `genero`
--

INSERT INTO `genero` (`id_genero`, `nome`) VALUES
(1, 'Hip Hop'),
(5, 'Jazz'),
(7, 'Neo Soul'),
(3, 'Pop'),
(2, 'R&B'),
(4, 'Rock'),
(6, 'Trap');

-- --------------------------------------------------------

--
-- Estrutura para tabela `musica`
--

CREATE TABLE `musica` (
  `id_musica` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `artista` varchar(150) NOT NULL,
  `album` varchar(150) DEFAULT NULL,
  `genero` varchar(100) DEFAULT NULL,
  `url_preview` varchar(255) DEFAULT NULL,
  `api_id` varchar(100) DEFAULT NULL,
  `id_genero` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `musica`
--

INSERT INTO `musica` (`id_musica`, `nome`, `artista`, `album`, `genero`, `url_preview`, `api_id`, `id_genero`) VALUES
(1, 'Musica Teste', 'Artista Teste', NULL, NULL, NULL, NULL, NULL),
(2, 'HUMBLE.', 'Kendrick Lamar', NULL, NULL, NULL, NULL, 1),
(3, 'Alright', 'Kendrick Lamar', NULL, NULL, NULL, NULL, 1),
(4, 'Brown Sugar', 'D’Angelo', NULL, NULL, NULL, NULL, 7),
(5, 'Get You', 'Daniel Caesar', NULL, NULL, NULL, NULL, 2),
(6, 'Blinding Lights', 'The Weeknd', NULL, NULL, NULL, NULL, 3),
(7, 'Bohemian Rhapsody', 'Queen', NULL, NULL, NULL, NULL, 4),
(8, 'Come Together', 'The Beatles', NULL, NULL, NULL, NULL, 4),
(9, 'No Role Modelz', 'J. Cole', NULL, NULL, NULL, NULL, 1),
(10, 'Redbone', 'Childish Gambino', NULL, NULL, NULL, NULL, 7),
(11, 'Starboy', 'The Weeknd', NULL, NULL, NULL, NULL, 3);

-- --------------------------------------------------------

--
-- Estrutura para tabela `postagem`
--

CREATE TABLE `postagem` (
  `id_postagem` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_musica` int(11) NOT NULL,
  `comentario` text DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `data_postagem` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `postagem`
--

INSERT INTO `postagem` (`id_postagem`, `id_usuario`, `id_musica`, `comentario`, `latitude`, `longitude`, `data_postagem`) VALUES
(9, 1, 1, 'Teste de apresentação', NULL, NULL, '2026-04-25 02:45:11'),
(10, 1, 1, 'Teste de apresentação', NULL, NULL, '2026-04-25 02:45:15'),
(11, 1, 1, 'Teste de apresentação', NULL, NULL, '2026-04-25 02:45:46'),
(12, 1, 1, 'Teste via app', NULL, NULL, '2026-04-25 02:55:34'),
(13, 1, 1, 'Teste via app', NULL, NULL, '2026-04-25 03:00:22'),
(14, 1, 1, 'Teste via app', NULL, NULL, '2026-04-25 03:08:59'),
(15, 1, 1, 'Teste via app', NULL, NULL, '2026-04-25 03:09:05'),
(16, 1, 1, 'Essa música é absurda 🔥', -15.79388900, -47.88277800, '2026-05-09 01:20:09'),
(17, 2, 3, 'Neo soul nunca decepciona', -15.79000000, -47.88000000, '2026-05-09 01:20:09'),
(18, 3, 5, 'The Weeknd é outro nível', -15.80000000, -47.87000000, '2026-05-09 01:20:09'),
(19, 4, 8, 'J. Cole é muito subestimado', -15.81000000, -47.86000000, '2026-05-09 01:20:09'),
(20, 5, 9, 'Essa vibe é perfeita de madrugada', -15.82000000, -47.85000000, '2026-05-09 01:20:09'),
(21, 1, 4, 'Daniel Caesar só lança pedrada', -15.78000000, -47.89000000, '2026-05-09 01:20:09'),
(22, 2, 6, 'Clássico eterno', -15.77000000, -47.90000000, '2026-05-09 01:20:09'),
(23, 3, 2, 'Kendrick nunca erra', -15.76000000, -47.91000000, '2026-05-09 01:20:09');

-- --------------------------------------------------------

--
-- Estrutura para tabela `seguidores`
--

CREATE TABLE `seguidores` (
  `id_seguidor` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_seguindo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `data_criacao` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nome`, `email`, `senha`, `foto`, `bio`, `data_criacao`) VALUES
(1, 'Usuario Teste', 'teste@email.com', '123', NULL, NULL, '2026-04-18 01:10:34'),
(2, 'Cayo', 'cayo@email.com', '123', NULL, NULL, '2026-05-09 01:17:19'),
(3, 'Joao', 'joao@email.com', '123', NULL, NULL, '2026-05-09 01:17:19'),
(4, 'Maria', 'maria@email.com', '123', NULL, NULL, '2026-05-09 01:17:19'),
(5, 'Ana', 'ana@email.com', '123', NULL, NULL, '2026-05-09 01:17:19'),
(6, 'Lucas', 'lucas@email.com', '123', NULL, NULL, '2026-05-09 01:17:19');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario_genero`
--

CREATE TABLE `usuario_genero` (
  `id_usuario` int(11) NOT NULL,
  `id_genero` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuario_musica`
--

CREATE TABLE `usuario_musica` (
  `id` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_musica` int(11) NOT NULL,
  `tipo` enum('favorita','curtida','historico') NOT NULL,
  `data_registro` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `comentario`
--
ALTER TABLE `comentario`
  ADD PRIMARY KEY (`id_comentario`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `idx_comentario_postagem` (`id_postagem`);

--
-- Índices de tabela `curtida`
--
ALTER TABLE `curtida`
  ADD PRIMARY KEY (`id_curtida`),
  ADD UNIQUE KEY `id_usuario` (`id_usuario`,`id_postagem`),
  ADD KEY `idx_curtida_postagem` (`id_postagem`);

--
-- Índices de tabela `genero`
--
ALTER TABLE `genero`
  ADD PRIMARY KEY (`id_genero`),
  ADD UNIQUE KEY `nome` (`nome`);

--
-- Índices de tabela `musica`
--
ALTER TABLE `musica`
  ADD PRIMARY KEY (`id_musica`),
  ADD UNIQUE KEY `api_id` (`api_id`),
  ADD KEY `fk_genero` (`id_genero`);

--
-- Índices de tabela `postagem`
--
ALTER TABLE `postagem`
  ADD PRIMARY KEY (`id_postagem`),
  ADD KEY `idx_postagem_usuario` (`id_usuario`),
  ADD KEY `idx_postagem_musica` (`id_musica`);

--
-- Índices de tabela `seguidores`
--
ALTER TABLE `seguidores`
  ADD PRIMARY KEY (`id_seguidor`),
  ADD UNIQUE KEY `id_usuario` (`id_usuario`,`id_seguindo`),
  ADD KEY `id_seguindo` (`id_seguindo`);

--
-- Índices de tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Índices de tabela `usuario_genero`
--
ALTER TABLE `usuario_genero`
  ADD PRIMARY KEY (`id_usuario`,`id_genero`),
  ADD KEY `id_genero` (`id_genero`);

--
-- Índices de tabela `usuario_musica`
--
ALTER TABLE `usuario_musica`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_musica` (`id_musica`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `comentario`
--
ALTER TABLE `comentario`
  MODIFY `id_comentario` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `curtida`
--
ALTER TABLE `curtida`
  MODIFY `id_curtida` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT de tabela `genero`
--
ALTER TABLE `genero`
  MODIFY `id_genero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `musica`
--
ALTER TABLE `musica`
  MODIFY `id_musica` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `postagem`
--
ALTER TABLE `postagem`
  MODIFY `id_postagem` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de tabela `seguidores`
--
ALTER TABLE `seguidores`
  MODIFY `id_seguidor` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `usuario_musica`
--
ALTER TABLE `usuario_musica`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `comentario`
--
ALTER TABLE `comentario`
  ADD CONSTRAINT `comentario_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE,
  ADD CONSTRAINT `comentario_ibfk_2` FOREIGN KEY (`id_postagem`) REFERENCES `postagem` (`id_postagem`) ON DELETE CASCADE;

--
-- Restrições para tabelas `curtida`
--
ALTER TABLE `curtida`
  ADD CONSTRAINT `curtida_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE,
  ADD CONSTRAINT `curtida_ibfk_2` FOREIGN KEY (`id_postagem`) REFERENCES `postagem` (`id_postagem`) ON DELETE CASCADE;

--
-- Restrições para tabelas `musica`
--
ALTER TABLE `musica`
  ADD CONSTRAINT `fk_genero` FOREIGN KEY (`id_genero`) REFERENCES `genero` (`id_genero`);

--
-- Restrições para tabelas `postagem`
--
ALTER TABLE `postagem`
  ADD CONSTRAINT `postagem_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE,
  ADD CONSTRAINT `postagem_ibfk_2` FOREIGN KEY (`id_musica`) REFERENCES `musica` (`id_musica`) ON DELETE CASCADE;

--
-- Restrições para tabelas `seguidores`
--
ALTER TABLE `seguidores`
  ADD CONSTRAINT `seguidores_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE,
  ADD CONSTRAINT `seguidores_ibfk_2` FOREIGN KEY (`id_seguindo`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE;

--
-- Restrições para tabelas `usuario_genero`
--
ALTER TABLE `usuario_genero`
  ADD CONSTRAINT `usuario_genero_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE,
  ADD CONSTRAINT `usuario_genero_ibfk_2` FOREIGN KEY (`id_genero`) REFERENCES `genero` (`id_genero`) ON DELETE CASCADE;

--
-- Restrições para tabelas `usuario_musica`
--
ALTER TABLE `usuario_musica`
  ADD CONSTRAINT `usuario_musica_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE CASCADE,
  ADD CONSTRAINT `usuario_musica_ibfk_2` FOREIGN KEY (`id_musica`) REFERENCES `musica` (`id_musica`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
