<?php
include 'conexao.php';

header('Content-Type: application/json');

$sql = "
SELECT
    m.nome,
    m.artista,
    COUNT(p.id_postagem) AS total
FROM postagem p
JOIN musica m ON p.id_musica = m.id_musica
GROUP BY m.id_musica
ORDER BY total DESC
LIMIT 10
";

$result = $conn->query($sql);

$dados = [];

while($row = $result->fetch_assoc()) {
    $dados[] = $row;
}

echo json_encode($dados);
?>