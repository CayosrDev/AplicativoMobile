package com.example.aplicativomusicamobile

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {

    @GET("login.php")
    fun login(
        @Query("email") email: String,
        @Query("senha") senha: String
    ): Call<LoginResponse>

    @GET("feed.php")
    fun feed(): Call<List<FeedPost>>

    @GET("curtir_postagem.php")
    fun curtir(
        @Query("id_usuario") idUsuario: Int,
        @Query("id_postagem") idPostagem: Int
    ): Call<Resposta>

    @GET("recomendacoes.php")
    fun recomendacoes(): Call<List<Recomendacao>>

    @GET("ranking_usuarios.php")
    fun rankingUsuarios(): Call<List<UsuarioRanking>>

    @GET("buscar_musica.php")
    fun buscarMusica(
        @Query("q") termo: String
    ): Call<List<MusicaBusca>>

    @GET("perfil_usuario.php")
    fun perfilUsuario(
        @Query("id_usuario") idUsuario: Int
    ): Call<PerfilUsuario>
}