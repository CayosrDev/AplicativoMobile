package com.example.aplicativomusicamobile

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RankingActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simple_list)

        recyclerView = findViewById(R.id.recyclerLista)
        recyclerView.layoutManager = LinearLayoutManager(this)

        RetrofitClient.api.rankingUsuarios().enqueue(object : Callback<List<UsuarioRanking>> {
            override fun onResponse(call: Call<List<UsuarioRanking>>, response: Response<List<UsuarioRanking>>) {
                val lista = response.body().orEmpty().mapIndexed { index, item ->
                    "${index + 1}º ${item.usuario}\nPostagens: ${item.total_postagens} | Curtidas recebidas: ${item.curtidas_recebidas}"
                }
                recyclerView.adapter = TextItemAdapter(lista)
            }

            override fun onFailure(call: Call<List<UsuarioRanking>>, t: Throwable) {
                Toast.makeText(this@RankingActivity, "Erro: ${t.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}