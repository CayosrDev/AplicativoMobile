<?php
include 'conexao.php';
header('Content-Type: application/json; charset=utf-8');

$sql = "
SELECT 
    u.id_usuario,
    u.nome AS usuario,
    COUNT(p.id_postagem) AS total_postagens,
    COALESCE((
        SELECT COUNT(*)
        FROM curtida c
        JOIN postagem p2 ON c.id_postagem = p2.id_postagem
        WHERE p2.id_usuario = u.id_usuario
    ), 0) AS curtidas_recebidas
FROM usuario u
LEFT JOIN postagem p ON p.id_usuario = u.id_usuario
GROUP BY u.id_usuario, u.nome
ORDER BY total_postagens DESC, curtidas_recebidas DESC, u.nome ASC
";

$result = $conn->query($sql);
$dados = [];

while ($row = $result->fetch_assoc()) {
    $dados[] = $row;
}

echo json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>