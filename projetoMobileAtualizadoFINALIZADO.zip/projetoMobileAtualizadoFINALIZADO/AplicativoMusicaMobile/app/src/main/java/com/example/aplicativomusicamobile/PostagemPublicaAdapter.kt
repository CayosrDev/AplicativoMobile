package com.example.aplicativomusicamobile

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PostagemPublicaAdapter(
    private val lista: List<PostagemPublica>
) : RecyclerView.Adapter<PostagemPublicaAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {

        val txtMusica: TextView =
            view.findViewById(R.id.txtMusica)

        val txtComentario: TextView =
            view.findViewById(R.id.txtComentario)
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): VH {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_postagem_publica, parent, false)

        return VH(view)
    }

    override fun getItemCount() = lista.size

    override fun onBindViewHolder(
        holder: VH,
        position: Int
    ) {

        val post = lista[position]

        holder.txtMusica.text =
            "🎵 ${post.musica} - ${post.artista}"

        holder.txtComentario.text =
            post.comentario
    }
}