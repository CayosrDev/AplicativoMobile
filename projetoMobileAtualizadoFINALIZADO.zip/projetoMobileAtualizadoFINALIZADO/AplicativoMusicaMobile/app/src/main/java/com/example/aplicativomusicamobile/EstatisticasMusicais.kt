package com.example.aplicativomusicamobile

data class EstatisticasMusicais(
    val genero_favorito: String,
    val artista_favorito: String,
    val musica_favorita: String
)