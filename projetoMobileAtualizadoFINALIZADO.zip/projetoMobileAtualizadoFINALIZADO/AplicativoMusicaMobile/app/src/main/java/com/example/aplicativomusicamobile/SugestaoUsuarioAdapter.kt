package com.example.aplicativomusicamobile

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SugestaoUsuarioAdapter(
    private var lista: List<SugestaoUsuario>,
    private val onClick: (SugestaoUsuario) -> Unit
) : RecyclerView.Adapter<SugestaoUsuarioAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val txtNome: TextView = view.findViewById(R.id.txtNomeSugestao)
        val txtBio: TextView = view.findViewById(R.id.txtBioSugestao)
        val txtCompat: TextView = view.findViewById(R.id.txtCompatSugestao)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_sugestao_usuario, parent, false)

        return VH(view)
    }

    override fun getItemCount() = lista.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val usuario = lista[position]

        holder.txtNome.text = usuario.usuario
        holder.txtBio.text = usuario.bio ?: "Sem bio"
        holder.txtCompat.text =
            "${usuario.compatibilidade}% compatível • ${usuario.generos_em_comum} gênero(s) em comum"

        holder.itemView.setOnClickListener {
            onClick(usuario)
        }
    }

    fun atualizar(novaLista: List<SugestaoUsuario>) {
        lista = novaLista
        notifyDataSetChanged()
    }
}