package com.example.aplicativomusicamobile

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SugestoesActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var txtVazio: TextView
    private lateinit var adapter: SugestaoUsuarioAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sugestoes)

        recycler = findViewById(R.id.recyclerSugestoes)
        txtVazio = findViewById(R.id.txtVazioSugestoes)

        recycler.layoutManager = LinearLayoutManager(this)

        adapter = SugestaoUsuarioAdapter(emptyList()) { usuario ->
            val intent = Intent(this, PublicProfileActivity::class.java)
            intent.putExtra("id_usuario", usuario.id_usuario)
            startActivity(intent)
        }

        recycler.adapter = adapter

        carregarSugestoes()
    }

    private fun carregarSugestoes() {
        RetrofitClient.api.sugestoesUsuarios(UsuarioSession.idUsuario)
            .enqueue(object : Callback<List<SugestaoUsuario>> {

                override fun onResponse(
                    call: Call<List<SugestaoUsuario>>,
                    response: Response<List<SugestaoUsuario>>
                ) {
                    val lista = response.body() ?: emptyList()

                    if (lista.isEmpty()) {
                        txtVazio.visibility = View.VISIBLE
                        recycler.visibility = View.GONE
                    } else {
                        txtVazio.visibility = View.GONE
                        recycler.visibility = View.VISIBLE
                        adapter.atualizar(lista)
                    }
                }

                override fun onFailure(
                    call: Call<List<SugestaoUsuario>>,
                    t: Throwable
                ) {
                    Toast.makeText(
                        this@SugestoesActivity,
                        "Erro: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }
}