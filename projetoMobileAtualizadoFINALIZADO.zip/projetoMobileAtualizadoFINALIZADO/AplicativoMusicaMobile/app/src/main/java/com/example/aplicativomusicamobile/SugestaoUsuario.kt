package com.example.aplicativomusicamobile

data class SugestaoUsuario(
    val id_usuario: Int,
    val usuario: String,
    val bio: String?,
    val generos_em_comum: Int,
    val total_generos_usuario: Int,
    val compatibilidade: Int
)