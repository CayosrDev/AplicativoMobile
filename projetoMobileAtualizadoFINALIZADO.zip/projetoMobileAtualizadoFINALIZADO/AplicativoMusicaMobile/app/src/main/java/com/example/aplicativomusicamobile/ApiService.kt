package com.example.aplicativomusicamobile

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {

    @GET("cadastro.php")
    fun cadastro(
        @Query("nome") nome: String,
        @Query("email") email: String,
        @Query("senha") senha: String
    ): Call<Resposta>

    @GET("login.php")
    fun login(
        @Query("email") email: String,
        @Query("senha") senha: String
    ): Call<LoginResponse>

    @GET("feed.php")
    fun feed(
        @Query("id_usuario") idUsuario: Int
    ): Call<List<FeedPost>>

    @GET("curtir_postagem.php")
    fun curtir(
        @Query("id_usuario") idUsuario: Int,
        @Query("id_postagem") idPostagem: Int
    ): Call<Resposta>

    @GET("recomendacoes.php")
    fun recomendacoes(): Call<List<Recomendacao>>

    @GET("ranking_usuarios.php")
    fun rankingUsuarios(): Call<List<UsuarioRanking>>

    @GET("buscar_musica.php")
    fun buscarMusica(
        @Query("q") termo: String
    ): Call<List<MusicaBusca>>

    @GET("perfil_usuario.php")
    fun perfilUsuario(
        @Query("id_usuario") idUsuario: Int
    ): Call<PerfilUsuario>

    @GET("nova_postagem.php")
    fun criarPostagem(
        @Query("id_usuario") idUsuario: Int,
        @Query("id_musica") idMusica: Int,
        @Query("comentario") comentario: String,
        @Query("latitude") latitude: Double?,
        @Query("longitude") longitude: Double?
    ): Call<Resposta>

    @GET("ranking_usuarios.php")
    fun ranking(): Call<List<Ranking>>

    @GET("buscar_id_musica.php")
    fun buscarIdMusica(
        @Query("nome") nome: String
    ): Call<MusicaId>

    @GET("minhas_postagens.php")
    fun minhasPostagens(
        @Query("id_usuario") idUsuario: Int
    ): Call<List<MinhaPostagem>>

    @GET("editar_perfil.php")
    fun editarPerfil(
        @Query("id_usuario") idUsuario: Int,
        @Query("nome") nome: String,
        @Query("bio") bio: String
    ): Call<Resposta>

    @GET("salvar_musica_deezer.php")
    fun salvarMusicaDeezer(
        @Query("nome") nome: String,
        @Query("artista") artista: String,
        @Query("album") album: String?,
        @Query("url_preview") urlPreview: String?,
        @Query("api_id") apiId: String?,
        @Query("capa_url") capaUrl: String?
    ): Call<SalvarMusicaResponse>

    @GET("descurtir_postagem.php")
    fun descurtir(
        @Query("id_usuario") idUsuario: Int,
        @Query("id_postagem") idPostagem: Int
    ): Call<Resposta>

    @GET("comentarios_postagem.php")
    fun comentariosPostagem(
        @Query("id_postagem") idPostagem: Int
    ): Call<List<ComentarioPostagem>>

    @GET("criar_comentario.php")
    fun criarComentario(
        @Query("id_postagem") idPostagem: Int,
        @Query("id_usuario") idUsuario: Int,
        @Query("comentario") comentario: String
    ): Call<Resposta>

    @GET("editar_postagem.php")
    fun editarPostagem(
        @Query("id") idPostagem: Int,
        @Query("comentario") comentario: String
    ): Call<Resposta>

    @GET("excluir_postagem.php")
    fun excluirPostagem(
        @Query("id") idPostagem: Int
    ): Call<Resposta>

    @GET("mapa_postagens.php")
    fun mapaPostagens(): Call<List<MapaPostagem>>

    @GET("compatibilidade.php")
    fun compatibilidade(
        @Query("id_usuario") idUsuario: Int
    ): Call<List<CompatibilidadeUsuario>>

    @GET("seguir_usuario.php")
    fun seguirUsuario(
        @Query("id_usuario") idUsuario: Int,
        @Query("id_seguindo") idSeguindo: Int
    ): Call<Resposta>

    @GET("listar_usuarios.php")
    fun listarUsuarios(): Call<List<Usuario>>

    @GET("estatisticas_usuario.php")
    fun estatisticasUsuario(
        @Query("id_usuario") idUsuario: Int
    ): Call<EstatisticasUsuario>

    @GET("status_seguir_usuario.php")
    fun statusSeguirUsuario(
        @Query("id_usuario") idUsuario: Int,
        @Query("id_seguindo") idSeguindo: Int
    ): Call<Resposta>

    @GET("postagens_usuario.php")
    fun postagensUsuario(
        @Query("id_usuario") idUsuario: Int
    ): Call<List<PostagemPublica>>

    @GET("sugestoes_usuarios.php")
    fun sugestoesUsuarios(
        @Query("id_usuario") idUsuario: Int
    ): Call<List<SugestaoUsuario>>

    @GET("estatisticas_musicais.php")
    fun estatisticasMusicais(
        @Query("id_usuario") idUsuario: Int
    ): Call<EstatisticasMusicais>


}
