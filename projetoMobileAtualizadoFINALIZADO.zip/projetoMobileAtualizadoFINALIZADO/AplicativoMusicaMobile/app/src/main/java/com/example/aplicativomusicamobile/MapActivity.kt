package com.example.aplicativomusicamobile

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.card.MaterialCardView
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MapActivity : AppCompatActivity() {

    private lateinit var mapView: MapView
    private lateinit var bottomNav: BottomNavigationView

    private lateinit var cardPostagensMapa: MaterialCardView
    private lateinit var recyclerPostagensMapa: RecyclerView
    private lateinit var txtTituloCardMapa: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        Configuration.getInstance().userAgentValue = packageName

        setContentView(R.layout.activity_map)

        mapView = findViewById(R.id.mapView)
        bottomNav = findViewById(R.id.bottomNav)

        cardPostagensMapa = findViewById(R.id.cardPostagensMapa)
        recyclerPostagensMapa = findViewById(R.id.recyclerPostagensMapa)
        txtTituloCardMapa = findViewById(R.id.txtTituloCardMapa)

        recyclerPostagensMapa.layoutManager =
            LinearLayoutManager(this)

        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.setMultiTouchControls(true)
        mapView.setOnTouchListener { _, _ ->
            cardPostagensMapa.visibility = View.GONE
            false
        }

        val centroInicial = GeoPoint(-16.6869, -49.2648)
        mapView.controller.setZoom(12.0)
        mapView.controller.setCenter(centroInicial)

        configurarMenu()
        carregarPostagensMapa()
    }

    private fun carregarPostagensMapa() {
        RetrofitClient.api.mapaPostagens()
            .enqueue(object : Callback<List<MapaPostagem>> {

                override fun onResponse(
                    call: Call<List<MapaPostagem>>,
                    response: Response<List<MapaPostagem>>
                ) {
                    val lista = response.body() ?: emptyList()

                    val marcadoresAntigos =
                        mapView.overlays.filterIsInstance<Marker>()

                    mapView.overlays.removeAll(marcadoresAntigos)

                    val grupos = lista
                        .filter { it.latitude != null && it.longitude != null }
                        .groupBy {
                            "${it.latitude}_${it.longitude}"
                        }

                    for ((_, postsDoLocal) in grupos) {
                        val primeiroPost = postsDoLocal.first()

                        val ponto = GeoPoint(
                            primeiroPost.latitude!!,
                            primeiroPost.longitude!!
                        )

                        val marker = Marker(mapView)
                        marker.position = ponto

                        marker.setAnchor(
                            Marker.ANCHOR_CENTER,
                            Marker.ANCHOR_BOTTOM
                        )

                        marker.setOnMarkerClickListener { _, _ ->
                            mostrarCardPostagens(postsDoLocal)
                            true
                        }

                        mapView.overlays.add(marker)
                    }

                    if (lista.isNotEmpty()) {
                        val primeiro = lista.first()

                        if (primeiro.latitude != null && primeiro.longitude != null) {
                            val pontoMaisRecente =
                                GeoPoint(
                                    primeiro.latitude,
                                    primeiro.longitude
                                )

                            mapView.controller.setZoom(16.0)
                            mapView.controller.animateTo(pontoMaisRecente)
                        }
                    }

                    mapView.invalidate()
                }

                override fun onFailure(
                    call: Call<List<MapaPostagem>>,
                    t: Throwable
                ) {
                }
            })
    }

    private fun mostrarCardPostagens(lista: List<MapaPostagem>) {
        cardPostagensMapa.visibility = View.VISIBLE

        txtTituloCardMapa.text =
            if (lista.size == 1)
                "Recomendação próxima"
            else
                "${lista.size} recomendações próximas"

        recyclerPostagensMapa.adapter =
            MapaPostagemAdapter(lista)
    }

    private fun configurarMenu() {
        bottomNav.selectedItemId = R.id.nav_map

        bottomNav.setOnItemSelectedListener {

            when (it.itemId) {

                R.id.nav_home -> {
                    startActivity(Intent(this, MainActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_search -> {
                    startActivity(Intent(this, SearchActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_feed -> {
                    startActivity(Intent(this, FeedActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_map -> true

                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                else -> false
            }
        }
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
        carregarPostagensMapa()
    }

    override fun onPause() {
        super.onPause()
        mapView.onPause()
    }
}