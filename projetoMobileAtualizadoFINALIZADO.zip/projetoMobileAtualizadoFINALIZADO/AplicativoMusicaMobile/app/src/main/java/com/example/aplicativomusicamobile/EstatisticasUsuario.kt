package com.example.aplicativomusicamobile

data class EstatisticasUsuario(
    val seguidores: Int,
    val seguindo: Int
)