package com.example.aplicativomusicamobile

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MapaPostagemAdapter(
    private val lista: List<MapaPostagem>
) : RecyclerView.Adapter<MapaPostagemAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val txtMusica: TextView = view.findViewById(R.id.txtMusicaMapa)
        val txtArtista: TextView = view.findViewById(R.id.txtArtistaMapa)
        val txtUsuario: TextView = view.findViewById(R.id.txtUsuarioMapa)
        val txtComentario: TextView = view.findViewById(R.id.txtComentarioMapa)
        val txtCurtidas: TextView = view.findViewById(R.id.txtCurtidasMapa)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_mapa_postagem, parent, false)

        return VH(view)
    }

    override fun getItemCount() = lista.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val post = lista[position]

        holder.txtMusica.text = "${post.musica}"
        holder.txtArtista.text = post.artista
        holder.txtUsuario.text = "${post.usuario}"
        holder.txtComentario.text = "${post.comentario ?: "Sem comentário"}"
        holder.txtCurtidas.text = "${post.curtidas} curtidas"
    }
}