package com.example.aplicativomusicamobile

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PublicProfileActivity : AppCompatActivity() {

    private lateinit var txtNome: TextView
    private lateinit var txtEmail: TextView
    private lateinit var txtBio: TextView
    private lateinit var txtCompatibilidade: TextView
    private lateinit var txtStats: TextView
    private lateinit var txtSeguidores: TextView
    private lateinit var txtGeneroFavorito: TextView
    private lateinit var txtArtistaFavorito: TextView
    private lateinit var txtMusicaFavorita: TextView
    private lateinit var txtSemPostagens: TextView

    private lateinit var btnSeguir: Button
    private lateinit var btnVerCompatibilidade: Button

    private lateinit var recyclerPostagens: RecyclerView

    private var idUsuarioVisitado = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_public_profile)

        txtNome = findViewById(R.id.txtNomePublico)
        txtEmail = findViewById(R.id.txtEmailPublico)
        txtBio = findViewById(R.id.txtBioPublica)
        txtCompatibilidade = findViewById(R.id.txtCompatibilidadePublica)
        txtStats = findViewById(R.id.txtStatsPublico)
        txtSeguidores = findViewById(R.id.txtSeguidoresPublico)
        txtGeneroFavorito = findViewById(R.id.txtGeneroFavoritoPublico)
        txtArtistaFavorito = findViewById(R.id.txtArtistaFavoritoPublico)
        txtMusicaFavorita = findViewById(R.id.txtMusicaFavoritaPublico)
        txtSemPostagens = findViewById(R.id.txtSemPostagens)

        btnSeguir = findViewById(R.id.btnSeguir)
        btnVerCompatibilidade = findViewById(R.id.btnVerCompatibilidadePublica)

        recyclerPostagens = findViewById(R.id.recyclerPostagensPublicas)
        recyclerPostagens.layoutManager = LinearLayoutManager(this)

        txtCompatibilidade.visibility = View.GONE

        idUsuarioVisitado = intent.getIntExtra("id_usuario", 0)

        carregarPerfilPublico()
        carregarEstatisticasUsuario()
        carregarEstatisticasMusicaisPublicas()
        carregarPostagensPublicas()
        carregarStatusSeguir()

        btnVerCompatibilidade.setOnClickListener {
            carregarCompatibilidade()
        }

        btnSeguir.setOnClickListener {
            RetrofitClient.api.seguirUsuario(
                UsuarioSession.idUsuario,
                idUsuarioVisitado
            ).enqueue(object : Callback<Resposta> {

                override fun onResponse(
                    call: Call<Resposta>,
                    response: Response<Resposta>
                ) {
                    val resposta = response.body()

                    Toast.makeText(
                        this@PublicProfileActivity,
                        resposta?.mensagem ?: "Ação realizada",
                        Toast.LENGTH_SHORT
                    ).show()

                    if (resposta?.seguindo == 1) {
                        btnSeguir.text = "Seguindo"
                    } else if (resposta?.seguindo == 0) {
                        btnSeguir.text = "Seguir"
                    }

                    carregarEstatisticasUsuario()
                }

                override fun onFailure(
                    call: Call<Resposta>,
                    t: Throwable
                ) {
                    Toast.makeText(
                        this@PublicProfileActivity,
                        "Erro: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        }
    }

    private fun carregarPostagensPublicas() {
        RetrofitClient.api.postagensUsuario(idUsuarioVisitado)
            .enqueue(object : Callback<List<PostagemPublica>> {

                override fun onResponse(
                    call: Call<List<PostagemPublica>>,
                    response: Response<List<PostagemPublica>>
                ) {
                    val lista = response.body() ?: emptyList()

                    if (lista.isEmpty()) {
                        txtSemPostagens.visibility = View.VISIBLE
                        recyclerPostagens.visibility = View.GONE
                    } else {
                        txtSemPostagens.visibility = View.GONE
                        recyclerPostagens.visibility = View.VISIBLE
                        recyclerPostagens.adapter = PostagemPublicaAdapter(lista)
                    }
                }

                override fun onFailure(
                    call: Call<List<PostagemPublica>>,
                    t: Throwable
                ) {
                }
            })
    }

    private fun carregarStatusSeguir() {
        RetrofitClient.api.statusSeguirUsuario(
            UsuarioSession.idUsuario,
            idUsuarioVisitado
        ).enqueue(object : Callback<Resposta> {

            override fun onResponse(
                call: Call<Resposta>,
                response: Response<Resposta>
            ) {
                val resposta = response.body()

                if (resposta?.seguindo == 1) {
                    btnSeguir.text = "Seguindo"
                } else {
                    btnSeguir.text = "Seguir"
                }
            }

            override fun onFailure(
                call: Call<Resposta>,
                t: Throwable
            ) {
            }
        })
    }

    private fun carregarPerfilPublico() {
        RetrofitClient.api.perfilUsuario(idUsuarioVisitado)
            .enqueue(object : Callback<PerfilUsuario> {

                override fun onResponse(
                    call: Call<PerfilUsuario>,
                    response: Response<PerfilUsuario>
                ) {
                    val perfil = response.body()

                    if (perfil != null) {
                        txtNome.text = perfil.nome
                        txtEmail.text = perfil.email
                        txtBio.text = perfil.bio ?: "Sem bio"
                        txtStats.text =
                            "Posts: ${perfil.total_postagens} | Curtidas: ${perfil.curtidas_recebidas}"
                    }
                }

                override fun onFailure(
                    call: Call<PerfilUsuario>,
                    t: Throwable
                ) {
                    Toast.makeText(
                        this@PublicProfileActivity,
                        "Erro: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
    }

    private fun carregarEstatisticasMusicaisPublicas() {
        RetrofitClient.api.estatisticasMusicais(idUsuarioVisitado)
            .enqueue(object : Callback<EstatisticasMusicais> {

                override fun onResponse(
                    call: Call<EstatisticasMusicais>,
                    response: Response<EstatisticasMusicais>
                ) {
                    val stats = response.body()

                    if (stats != null) {
                        txtGeneroFavorito.text =
                            "🎵 Gênero favorito: ${stats.genero_favorito}"

                        txtArtistaFavorito.text =
                            "🎤 Artista favorito: ${stats.artista_favorito}"

                        txtMusicaFavorita.text =
                            "⭐ Música favorita: ${stats.musica_favorita}"
                    }
                }

                override fun onFailure(
                    call: Call<EstatisticasMusicais>,
                    t: Throwable
                ) {
                }
            })
    }

    private fun carregarEstatisticasUsuario() {
        RetrofitClient.api.estatisticasUsuario(idUsuarioVisitado)
            .enqueue(object : Callback<EstatisticasUsuario> {

                override fun onResponse(
                    call: Call<EstatisticasUsuario>,
                    response: Response<EstatisticasUsuario>
                ) {
                    val stats = response.body()

                    if (stats != null) {
                        txtSeguidores.text =
                            "Seguidores: ${stats.seguidores} | Seguindo: ${stats.seguindo}"
                    }
                }

                override fun onFailure(
                    call: Call<EstatisticasUsuario>,
                    t: Throwable
                ) {
                }
            })
    }

    private fun carregarCompatibilidade() {
        txtCompatibilidade.visibility = View.VISIBLE

        RetrofitClient.api.compatibilidade(UsuarioSession.idUsuario)
            .enqueue(object : Callback<List<CompatibilidadeUsuario>> {

                override fun onResponse(
                    call: Call<List<CompatibilidadeUsuario>>,
                    response: Response<List<CompatibilidadeUsuario>>
                ) {
                    val lista = response.body() ?: emptyList()

                    val usuarioCompat =
                        lista.find { it.id_usuario == idUsuarioVisitado }

                    if (usuarioCompat != null) {
                        txtCompatibilidade.text =
                            "${usuarioCompat.compatibilidade}% compatível\n${usuarioCompat.generos_em_comum} gênero(s) em comum"
                    } else {
                        txtCompatibilidade.text =
                            "Sem compatibilidade calculada"
                    }
                }

                override fun onFailure(
                    call: Call<List<CompatibilidadeUsuario>>,
                    t: Throwable
                ) {
                    txtCompatibilidade.text =
                        "Compatibilidade indisponível"
                }
            })
    }
}