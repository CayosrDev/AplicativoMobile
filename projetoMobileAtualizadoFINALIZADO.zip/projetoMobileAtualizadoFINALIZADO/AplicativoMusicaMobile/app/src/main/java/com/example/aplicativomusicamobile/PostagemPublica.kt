package com.example.aplicativomusicamobile

data class PostagemPublica(
    val id_postagem: Int,
    val musica: String,
    val artista: String,
    val comentario: String
)