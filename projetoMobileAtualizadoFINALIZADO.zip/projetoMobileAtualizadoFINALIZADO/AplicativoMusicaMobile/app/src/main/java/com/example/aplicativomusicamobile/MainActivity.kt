package com.example.aplicativomusicamobile

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var txtUsuario: TextView
    private lateinit var bottomNav: BottomNavigationView

    private lateinit var txtHomeGenero: TextView
    private lateinit var txtHomeArtista: TextView
    private lateinit var txtHomeMusica: TextView

    private lateinit var recyclerBrasil: RecyclerView
    private lateinit var recyclerMundo: RecyclerView
    private lateinit var recyclerFeedHome: RecyclerView
    private lateinit var recyclerRankingHome: RecyclerView
    private lateinit var recyclerSugestoesHome: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtUsuario = findViewById(R.id.txtUsuario)
        bottomNav = findViewById(R.id.bottomNav)

        txtHomeGenero = findViewById(R.id.txtHomeGenero)
        txtHomeArtista = findViewById(R.id.txtHomeArtista)
        txtHomeMusica = findViewById(R.id.txtHomeMusica)

        recyclerBrasil = findViewById(R.id.recyclerBrasil)
        recyclerMundo = findViewById(R.id.recyclerMundo)
        recyclerFeedHome = findViewById(R.id.recyclerFeedHome)
        recyclerRankingHome = findViewById(R.id.recyclerRankingHome)
        recyclerSugestoesHome = findViewById(R.id.recyclerSugestoesHome)

        recyclerBrasil.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        recyclerMundo.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        recyclerFeedHome.layoutManager = LinearLayoutManager(this)
        recyclerRankingHome.layoutManager = LinearLayoutManager(this)
        recyclerSugestoesHome.layoutManager = LinearLayoutManager(this)

        txtUsuario.text = "Bem vindo, ${UsuarioSession.nomeUsuario}"

        carregarTopBrasil()
        carregarTopMundo()
        carregarFeedHome()
        carregarRankingHome()
        carregarEstatisticasHome()
        carregarSugestoesHome()

        configurarMenuInferior()
    }

    private fun carregarTopBrasil() {
        DeezerClient.api.topBrasil()
            .enqueue(object : Callback<DeezerResponse> {
                override fun onResponse(
                    call: Call<DeezerResponse>,
                    response: Response<DeezerResponse>
                ) {
                    response.body()?.let {
                        recyclerBrasil.adapter =
                            HomeMusicAdapter(it.data.take(10)) { musica ->
                                abrirDetalhesMusica(musica)
                            }
                    }
                }

                override fun onFailure(call: Call<DeezerResponse>, t: Throwable) {}
            })
    }

    private fun carregarTopMundo() {
        DeezerClient.api.topMundo()
            .enqueue(object : Callback<DeezerResponse> {
                override fun onResponse(
                    call: Call<DeezerResponse>,
                    response: Response<DeezerResponse>
                ) {
                    response.body()?.let {
                        recyclerMundo.adapter =
                            HomeMusicAdapter(it.data.take(10)) { musica ->
                                abrirDetalhesMusica(musica)
                            }
                    }
                }

                override fun onFailure(call: Call<DeezerResponse>, t: Throwable) {}
            })
    }

    private fun carregarEstatisticasHome() {
        RetrofitClient.api.estatisticasMusicais(UsuarioSession.idUsuario)
            .enqueue(object : Callback<EstatisticasMusicais> {

                override fun onResponse(
                    call: Call<EstatisticasMusicais>,
                    response: Response<EstatisticasMusicais>
                ) {
                    val stats = response.body()

                    if (stats != null) {
                        txtHomeGenero.text =
                            "Gênero favorito: ${stats.genero_favorito}"

                        txtHomeArtista.text =
                            "Artista favorito: ${stats.artista_favorito}"

                        txtHomeMusica.text =
                            "Música favorita: ${stats.musica_favorita}"
                    }
                }

                override fun onFailure(
                    call: Call<EstatisticasMusicais>,
                    t: Throwable
                ) {}
            })
    }

    private fun carregarSugestoesHome() {
        RetrofitClient.api.sugestoesUsuarios(UsuarioSession.idUsuario)
            .enqueue(object : Callback<List<SugestaoUsuario>> {

                override fun onResponse(
                    call: Call<List<SugestaoUsuario>>,
                    response: Response<List<SugestaoUsuario>>
                ) {
                    val lista = response.body()
                        ?.take(3)
                        ?.map {
                            "${it.usuario} — ${it.compatibilidade}% compatível"
                        } ?: emptyList()

                    recyclerSugestoesHome.adapter =
                        TextItemAdapter(lista)
                }

                override fun onFailure(
                    call: Call<List<SugestaoUsuario>>,
                    t: Throwable
                ) {}
            })
    }

    private fun carregarFeedHome() {
        RetrofitClient.api.feed(UsuarioSession.idUsuario)
            .enqueue(object : Callback<List<FeedPost>> {

                override fun onResponse(
                    call: Call<List<FeedPost>>,
                    response: Response<List<FeedPost>>
                ) {
                    val lista = response.body()
                        ?.take(3)
                        ?.map {
                            "🎵 ${it.musica}\n${it.usuario}: ${it.comentario}"
                        } ?: emptyList()

                    recyclerFeedHome.adapter =
                        TextItemAdapter(lista)
                }

                override fun onFailure(
                    call: Call<List<FeedPost>>,
                    t: Throwable
                ) {}
            })
    }

    private fun carregarRankingHome() {
        RetrofitClient.api.rankingUsuarios()
            .enqueue(object : Callback<List<UsuarioRanking>> {

                override fun onResponse(
                    call: Call<List<UsuarioRanking>>,
                    response: Response<List<UsuarioRanking>>
                ) {
                    val lista = response.body()
                        ?.take(5)
                        ?.mapIndexed { index, usuario ->
                            "${index + 1}. ${usuario.usuario} — ${usuario.curtidas_recebidas} curtidas"
                        } ?: emptyList()

                    recyclerRankingHome.adapter =
                        TextItemAdapter(lista)
                }

                override fun onFailure(
                    call: Call<List<UsuarioRanking>>,
                    t: Throwable
                ) {}
            })
    }

    private fun abrirDetalhesMusica(musica: MusicaDeezer) {
        val intent = Intent(this, MusicDetailActivity::class.java)

        intent.putExtra("titulo", musica.title)
        intent.putExtra("artista", musica.artist.name)
        intent.putExtra("capa", musica.album.cover_medium)
        intent.putExtra("preview", musica.preview)

        startActivity(intent)
    }

    private fun configurarMenuInferior() {
        bottomNav.selectedItemId = R.id.nav_home

        bottomNav.setOnItemSelectedListener {
            when (it.itemId) {

                R.id.nav_home -> true

                R.id.nav_search -> {
                    startActivity(Intent(this, SearchActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_feed -> {
                    startActivity(Intent(this, FeedActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_map -> {
                    startActivity(Intent(this, MapActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                R.id.nav_profile -> {
                    startActivity(Intent(this, ProfileActivity::class.java))
                    overridePendingTransition(0, 0)
                    finish()
                    true
                }

                else -> false
            }
        }
    }
}