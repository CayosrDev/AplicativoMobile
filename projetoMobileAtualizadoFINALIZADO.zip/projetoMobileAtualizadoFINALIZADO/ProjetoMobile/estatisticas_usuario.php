<?php
include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

$id_usuario = intval($_GET['id_usuario']);

$sql = "
SELECT
    (SELECT COUNT(*) FROM seguidores WHERE id_seguindo = ?) AS seguidores,
    (SELECT COUNT(*) FROM seguidores WHERE id_usuario = ?) AS seguindo
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id_usuario, $id_usuario);
$stmt->execute();

$result = $stmt->get_result();
$dados = $result->fetch_assoc();

$dados['seguidores'] = intval($dados['seguidores']);
$dados['seguindo'] = intval($dados['seguindo']);

echo json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
