<?php

include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

$id_usuario = intval($_GET['id_usuario']);

$resposta = [];

/* GÊNERO FAVORITO */

$sqlGenero = "
SELECT
    g.nome,
    COUNT(*) total
FROM curtida c
JOIN postagem p ON c.id_postagem = p.id_postagem
JOIN musica m ON p.id_musica = m.id_musica
JOIN genero g ON m.id_genero = g.id_genero
WHERE c.id_usuario = ?
GROUP BY g.id_genero
ORDER BY total DESC
LIMIT 1
";

$stmt = $conn->prepare($sqlGenero);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();

$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $resposta["genero_favorito"] = $row["nome"];
} else {
    $resposta["genero_favorito"] = "Sem dados";
}

/* ARTISTA FAVORITO */

$sqlArtista = "
SELECT
    m.artista,
    COUNT(*) total
FROM curtida c
JOIN postagem p ON c.id_postagem = p.id_postagem
JOIN musica m ON p.id_musica = m.id_musica
WHERE c.id_usuario = ?
GROUP BY m.artista
ORDER BY total DESC
LIMIT 1
";

$stmt = $conn->prepare($sqlArtista);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();

$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $resposta["artista_favorito"] = $row["artista"];
} else {
    $resposta["artista_favorito"] = "Sem dados";
}

/* MÚSICA FAVORITA */

$sqlMusica = "
SELECT
    m.nome,
    COUNT(*) total
FROM curtida c
JOIN postagem p ON c.id_postagem = p.id_postagem
JOIN musica m ON p.id_musica = m.id_musica
WHERE c.id_usuario = ?
GROUP BY m.id_musica
ORDER BY total DESC
LIMIT 1
";

$stmt = $conn->prepare($sqlMusica);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();

$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $resposta["musica_favorita"] = $row["nome"];
} else {
    $resposta["musica_favorita"] = "Sem dados";
}

echo json_encode(
    $resposta,
    JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
);
