<?php
include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

$sql = "
SELECT
    p.id_postagem,
    u.nome AS usuario,
    m.nome AS musica,
    m.artista,
    p.comentario,
    p.latitude,
    p.longitude,
    COUNT(c.id_curtida) AS curtidas
FROM postagem p
JOIN usuario u ON p.id_usuario = u.id_usuario
JOIN musica m ON p.id_musica = m.id_musica
LEFT JOIN curtida c ON c.id_postagem = p.id_postagem
WHERE p.latitude IS NOT NULL
AND p.longitude IS NOT NULL
GROUP BY
    p.id_postagem,
    u.nome,
    m.nome,
    m.artista,
    p.comentario,
    p.latitude,
    p.longitude
ORDER BY p.data_postagem DESC
";

$result = $conn->query($sql);

$dados = [];

while ($row = $result->fetch_assoc()) {
    $row['id_postagem'] = intval($row['id_postagem']);
    $row['latitude'] = floatval($row['latitude']);
    $row['longitude'] = floatval($row['longitude']);
    $row['curtidas'] = intval($row['curtidas']);

    $dados[] = $row;
}

echo json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>