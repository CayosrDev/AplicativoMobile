<?php
include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

$id_usuario = intval($_GET['id_usuario']);
$id_seguindo = intval($_GET['id_seguindo']);

$sql = "
SELECT id_seguidor
FROM seguidores
WHERE id_usuario = ?
AND id_seguindo = ?
LIMIT 1
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $id_usuario, $id_seguindo);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo json_encode([
        "status" => "ok",
        "seguindo" => 1
    ]);
} else {
    echo json_encode([
        "status" => "ok",
        "seguindo" => 0
    ]);
}
?>