<?php

include 'conexao.php';

header('Content-Type: application/json; charset=utf-8');

$id_usuario = intval($_GET['id_usuario']);

$sql = "
SELECT
    p.id_postagem,
    m.nome AS musica,
    m.artista,
    p.comentario,
    p.data_postagem
FROM postagem p
JOIN musica m
ON p.id_musica = m.id_musica
WHERE p.id_usuario = ?
ORDER BY p.data_postagem DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_usuario);
$stmt->execute();

$result = $stmt->get_result();

$dados = [];

while($row = $result->fetch_assoc()){
    $dados[] = $row;
}

echo json_encode(
    $dados,
    JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT
);
?>